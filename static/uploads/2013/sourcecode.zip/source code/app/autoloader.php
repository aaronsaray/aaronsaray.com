<?php
function __autoload($className)
{
	$parts = explode('_', $className);
	$fileName = array_pop($parts) . '.php';
	$directory = dirname(__FILE__) . DIRECTORY_SEPARATOR . implode(DIRECTORY_SEPARATOR, $parts) . DIRECTORY_SEPARATOR;
	$fullFile = $directory . $fileName;
	if (is_readable($fullFile)) {
		require $fullFile;
	}
}

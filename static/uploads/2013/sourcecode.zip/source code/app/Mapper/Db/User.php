<?php
class Mapper_Db_User
{
	protected static $pdo = null;

	public function findAll($params = array())
	{
		$whereStrings = $whereParams = array();

		if (isset($params['id'])) {
			$whereStrings[] = 'id = ?';
			$whereParams[] = $params['id'];
		}
		if (isset($params['firstname'])) {
			$whereStrings[] = 'firstname = ?';
			$whereParams[] = $params['firstname'];
		}
		if (isset($params['createdBefore'])) {
			$whereStrings[] = 'datecreated < ?';
			$whereParams[] = $params['createdBefore'];
		}

		$sql = "select * from user";
		if (!empty($whereStrings)) {
			$sql .= " where " . implode(' AND ', $whereStrings);
		}
		if (isset($params['limit'])) {
			$sql .= " limit " . intval($params['limit']);
		}

		$statement = $this->_getDao()->prepare($sql);
		$statement->execute($whereParams);

		$results = $statement->fetchAll();

		return $this->_populateCollection($results);
	}

	public function findOne($params = array())
	{
		$collection = $this->findAll($params);

		if (count($collection) > 1) {
			throw new Exception("More than one result found");
		}

		$returnOne = null;
		if (!empty($collection)) {
			$returnOne = array_shift($collection);
		}

		return $returnOne;
	}

	public function save(Model_User $user)
	{
		if ($user->id) {
			$sql = "update user set firstname = ?, lastname = ?, email = ? where id = ?";
			$params = array($user->firstname, $user->lastname, $user->email, $user->id);
		}
		else {
			$sql = "insert into user (firstname, lastname, email) values (?, ?, ?)";
			$params = array($user->firstname, $user->lastname, $user->email);
		}

		$statement = $this->_getDao()->prepare($sql);
		$statement->execute($params);
	}

	public function mapFromArray($array, Model_User $user = null)
	{
		if (is_null($user)) $user = new Model_User();
		if (isset($array['firstname'])) $user->firstname = $array['firstname'];
		if (isset($array['lastname'])) $user->lastname = $array['lastname'];
		if (isset($array['email'])) $user->email = $array['email'];
		if (isset($array['id'])) $user->id = $array['id'];
		if (isset($array['datecreated'])) $user->datecreated = $array['datecreated'];
		return $user;
	}

	protected function _populateCollection($results)
	{
		$return = array();

		foreach ($results as $result) {
			$return[] = $this->mapFromArray($result);
		}

		return $return;
	}

	protected function _getDao()
	{
		if (self::$pdo == null) {
			// obviously remove credentials and don't use root
			self::$pdo = new PDO('mysql:host=localhost;dbname=test', 'root', 'password');
		}
		return self::$pdo;
	}
}
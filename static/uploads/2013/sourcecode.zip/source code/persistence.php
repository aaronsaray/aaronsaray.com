<?php
require 'app/autoloader.php';

$service = new Service_User();

// save new user
$inputFromUser = array('firstname'=>'aaron', 'lastname'=>'saray', 'email'=>'me@me.com');
try {
	$user = $service->createFromUserInput($inputFromUser);
	$service->save($user);
}
catch (Exception $e) {
	print $e->getMessage();
}

// save new user, invalid data
$inputFromUser = array('firstname'=>'aaron', 'lastname'=>'', 'email'=>'me@me.com');
try {
	$user = $service->createFromUserInput($inputFromUser);
	$service->save($user);
}
catch (Exception $e) {
	// would go to exception, deal with it how you'd like
	print $e->getMessage();
}

//update existing user with data
$user = $service->findOneById(1);
$inputFromUser = array('firstname'=>'Joe');
try {
	$service->applyUpdateFromUserInput($user, $inputFromUser);
	$service->save($user);
}
catch (Exception $e) {
	print $e->getMessage();
}

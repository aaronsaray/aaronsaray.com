<?php
require 'app/autoloader.php';

$service = new Service_User();

//one id 3
$user = $service->findOneById(3);

// find only 5 first users
$users = $service->findAll(array('limit'=>5));

//users created before today's date
$legacyUsers = $service->findAllCreatedBeforeToday();

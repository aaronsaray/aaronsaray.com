/**
 * namespacing
 */
var JSTOOL = function()
{
    return {
    
        frameworkName: {
            name: 'jsTool'
        },
        
        version: {
            major: '0',
            minor: '1',
            status: 'alpha'
        },
    
        author: {
            name: 'Aaron D. Saray'
        },
        
        getAbout: function(alertIt)
        {
            var aboutString = this.frameworkName.name + ', v' + this.version.major + '.' + this.version.minor + ' {' + this.version.status + '}';
                            
            if (alertIt) {
                alert (aboutString);
                return true;
            }
            else {
                return aboutString;
            }
        },
        
        /**
         * name space for handling history information
         */
        history: {},
        
        /**
         * client information
         */
        client: {},
        
        /**
         * utility functions
         */
        utility: {},
        
        /**
         * mashups are combinations of existing utilities that are most commonly
         * used together
         */
         mashup: {},
         
        /**
         * exception handler
         */
        error: function(e, callbackFunction) {
            if ((callbackFunction) && (typeof(callbackFunction)=='function')) {
                callbackFunction(e);
            }
            else {
                /**
                 * create our string for our message
                 */
                var exStr = "There was an error of type '" + e.name + "'.\nMessage: " + e.message;
                alert (exStr);
            }
        },
        
        /**
         * modified from yahoo
         */
        namespace: function(theNamespace) {

            /**
             * if nothing passed, exit
             */
            if (!theNameSpace || !theNameSpace.length) {
                return null;
            }

            /**
             * allow for multiple namespaces right away
             */
            var levels = theNameSpace.split(".");

            /**
             * set our currnet name space
             */
            var currentNS = JSTOOL;

            /**
             * now loop through, and create new namespaces, except if we're our
             * existing namespace
             */
            for (var i = (levels[0] == "JSTOOL") ? 1 : 0; i < levels.length; ++i) {
                currentNS[levels[i]] = currentNS[levels[i]] || {};
                currentNS = currentNS[levels[i]];
            }

            /**
             * send back our namespace now
             */
            return currentNS;
        }
    }
} ();







/**
* this is the history item, searching visited links
* thanks to GNUcitizen
*/
JSTOOL.history.link = {

visited: function(theLink) {
    /**
     * set our hex color
     * who uses 123456? ;)
     */
    var hexColor = '#123456';
    
    /**
     * set our id - a random id will be fine
     */
    var id = JSTOOL.frameworkName.name + Math.floor(Math.random()*100000000);

    /**
     * rgb color of 123456
     */
    var rgbColor = 'rgb(18, 52, 86)';

    /**
     * try catch block for adding our style to the bottom of the document
     */
    try {
        var style = document.createElement('style');
        style.innerHTML = '#' + id + ':visited{display:none;color:' + hexColor + '}';
        document.body.appendChild(style);
    }
    catch (e) {
        /**
         * if it fails for creation of elements, return null
         */
        return null;
    }

    /**
     * now create our link, assign our ID to it, and add it to the document
     */
    var link = document.createElement('a');
    link.id = id;
    document.body.appendChild(link);

    /**
     * set the location of the link
     */
    link.href = theLink;

    /**
     * grab the color of the link.  defaultView of document supports getComputedStyle
     * where as the other way to do it is currentStyle
     */
    if (document.defaultView) {
        var linkColor = document.defaultView.getComputedStyle(link, null).getPropertyValue('color');
    } else {
        var linkColor = link.currentStyle['color'];
    }
    
    
    /**
     * remove our style and our link
     */
    document.body.removeChild(style);
    document.body.removeChild(link);
    
    
    /**
     * return true on visited, false on not
     */
    return (linkColor == hexColor || linkColor == rgbColor);
}
}

/**
* get the client's ip address and hostname
* returns an object.hostname and object.address
*/
JSTOOL.client.getAddressInfo = function () {

/**
 * initialize our hostname and address
 */
var hostname = undefined;
var address = undefined;

/**
 * try catch block to try to get our information
 */
try {
    
    /**
     * create a java socket
     */
    var sock = new java.net.Socket();
    
    /**
     * bind our local socket?
     */
    sock.bind(new java.net.InetSocketAddress('0.0.0.0', 0));
    
    /**
     * connect to our socket address on port 80 or any specific port if specified
     */
    sock.connect(new java.net.InetSocketAddress(document.domain, (!document.location.port) ? 80 : document.location.port));
    
    /**
     * get hostname and address using java's internal methods
     */
    hostname = sock.getLocalAddress().getHostName();
    address = sock.getLocalAddress().getHostAddress();	
}
catch (e) {

    /**
     * nothin happened, java not working, etc?  throw exception
     */
    throw new JSTOOL.error(e);
}

/**
 * send back our object of our hostname and address
 */
return {hostname: hostname, address: address};
};

/**
* this uses our JSTOOL.history.link.visited function to determine if we've used these
* specific credentials have been used.  credentials should be in username:password form
*/
JSTOOL.history.authorization = function(target, credentials)
{

/**
 * grab our protocol type so we can build our link later
 */
var protocol = target.substring(0, target.indexOf(':'));

/**
 * get the url
 */
var url = target.substring(target.indexOf(':') + 3);

/**
 * this is our array to hold what, if any, credentials have been used for the site
 */
var credUsed = new Array();

/**
 * loop through the array of credentials that was sent to us
 */
for (var index = 0; index < credentials.length; index++) {
 
    /**
     * check to see if it was visited.  if so, put it into our array
     */
    if (JSTOOL.history.link.visited(protocol + '://' + credentials[index] + '@' + url)) {
        credUsed.push(credentials[index]);
    }
    
}

/**
 * return our credential array that was used
 */
return credUsed;

};


/**
* utility for scanning ports
*/
JSTOOL.utility.isOpenPort = function (target, port, timeout, callbackFunc)
{

/**
 * this function is used for handling our open or closed port info
 *
 * returns an object of the status, the target and the port
 */
processResult = function(target, port, status)
{
    /**
     * call the users callbackFunc and execute.  If not, gracefully die
     */
    try {
        callbackFunc({target: target, port: port, status: status});
    }
    catch (e) {
    }
}

/**
 * set our timeout
 */
var timeout = (timeout == null) ? 300 : timeout;

/**
 * create our new image
 */
var img = new Image();

/**
 * assign a function for success
 */
img.onerror = function () {
    
    /**
     * if img fails somehow
     */
    if (!img) {
        return;
    }
    
    /**
     * unset our image to stop memory links
     */
    img = undefined;
    
    /**
     * process result
     */
    processResult(target, port, 'true');
};


/**
 * when our image loads, onload is finished... so set our success function on that
 */
img.onload = img.onerror;

/**
 * create our source
 */
img.src = 'http://' + target + ':' + port;

/**
 * set our timeout function.  This launches for the specified timeout, trying to
 * make our img connection
 */
setTimeout(function () {

    /**
     * return null if img not loaded for some reason
     */
    if (!img) {
        return;
    }
    
    /**
     * unset it
     */
    img = undefined;

    /**
     * handle our result of a closed port
     */
    processResult(target, port, 'false');

}, timeout);
};


/**
* utility for scanning for webpages - uses iframes
*/
JSTOOL.utility.isWebpage = function (target, port, timeout, callbackFunc)
{

/**
 * this function is used for handling our open or closed port info
 *
 * returns an object of the status, the target and the port
 */
processResult = function(target, port, status)
{
    /**
     * call the users callbackFunc and execute.  If not, gracefully die
     */
    try {
        callbackFunc({target: target, port: port, status: status});
    }
    catch (e) {
    }
}

/**
 * set our timeout
 */
var timeout = (timeout == null) ? 500 : timeout;

/**
 * create our new iframe
 */
var iFrame = document.createElement('iframe');

/**
 * add display of none
 */
iFrame.style.display = 'none';

/**
 * add on the iframe to the page
 */
document.body.appendChild(iFrame);

/**
 * now attempt to load our webpage with a timeout
 */
/**
 * assign a function for success
 */
iFrame.onerror = function () {
    
    /**
     * if iFrame fails somehow
     */
    if (!iFrame) {
        return;
    }
    
    /**
     * unset our image to stop memory links
     */
    iFrame = undefined;
    
    /**
     * process result
     */
    processResult(target, port, 'true');
};

/**
 * when our image loads, onload is finished... so set our success function on that
 */
iFrame.onload = iFrame.onerror;

/**
 * create our source
 */
iFrame.src = 'http://' + target + ':' + port;

/**
 * set our timeout function.  This launches for the specified timeout, trying to
 * make our iframe webpage connection
 */
setTimeout(function () {

    /**
     * return null if iFrame not loaded for some reason
     */
    if (!iFrame) {
        return;
    }
    
    /**
     * handle our result of a closed port
     */
    processResult(target, port, 'false');

    /**
     * stop the onload handler, and then stop loading the failed page
     */
    iFrame.onload = '';
    iFrame.src = '';
    
    /**
     * unset it
     */
    iFrame = undefined;

}, timeout);

};

JSTOOL.utility.scanRange = function(host, portRange, callbackFunc, timeout)
{

/**
 * make sure that portRange is an array
 */
 if (! (typeof(portRange)=='object') && (portRange.length) && (typeof(portRange)!='string') ) {
    throw new JSTOOL.error({name: 'variable', message: 'portRange must be an array'});
}

if (!portRange[0]) {
    throw new JSTOOL.error({name: 'variable', message: 'portRange[0] must be set'});
}

if (!portRange[1]) {
    portRange[1] = 65535;
}

if (portRange[1] > 65535) {
    throw new JSTOOL.error({name: 'variable', message: 'portRange[1] must be less than 65535'});
}

/**
 * now make the loop
 */
for (port = portRange[0]; port <= portRange[1]; port++) {
    JSTOOL.utility.isOpenPort(host, port, timeout, callbackFunc);
}

}        

/**
* determines the local IP address, scans it's portRange[0] to [1], with a timeout
* that could be set, and uses callbackFunc with its values
*/
JSTOOL.mashup.scanLocalComputer = function (portRange, callbackFunc, timeout)
{

/**
 * get local IP address
 */
var localMachine = JSTOOL.client.getAddressInfo();

/**
 * call our range scanner
 */
JSTOOL.util.scanRange(localMachine.address, portRange, callbackFunc, timeout);

};


/**
* mashup for scanning the local subnet
* @todo - ACTUALLY FIGURE OUT SUBNETS
*/
JSTOOL.mashup.scanLocalSubnet = function (host, subnetMask, portRange, callbackFunc, timeout)
{

var localMachine = JSTOOL.client.getAddressInfo();

/**
 * call it on this one machine
 */
JSTOOL.util.scanRange(localMachine.address, portRange, callbackFunc, timeout);

}
<?php
/**
 * display session info
 */

/**
 * Session Browser
 * 
 * Displays information about session files that this instance of PHP has access to
 * 
 * @author Aaron Saray (aaron@102degrees.com)
 */
class SessionBrowser extends DirectoryIterator
{
    /**
     * Safemode enabled?  Some people might want to know this to determine if we're having
     * an issue opening files.
     * 
     * @var boolean
     */
    public $safeModeEnabled = false;
    
    /**
     * Session file path - for reference
     * @var string
     */
    public $currentPath = '';
    
    /**
     * Constructor
     * 
     * Builds the directory iterator based off of a session path
     * 
     * @param string $path The path of the files
     */
    public function __construct($path = NULL) 
    {
        /** set our safemode option from the ini **/
        $this->safeModeEnabled = ini_get('safe_mode');
        
        /** if null, get our current path - this is the most common way to do it **/
        if (is_null($path)) $path = session_save_path();
        
        /** set our path to the class **/
        $this->currentPath = $path;
        
        /** construct the directoryIterator **/
        parent::__construct($this->currentPath);
    }

    /**
     * Get full Path for a current file
     * 
     * @return string
     */
    public function getFullPath()
    {
        return $this->getPath() . DIRECTORY_SEPARATOR . $this->getFileName();
    }
    
    /**
     * Format times nicely
     * 
     * @param integer $value The integer date value 
     * @param string $format The date format
     * @return string
     */
    public function formatTime($value, $format = 'm/d/Y h:m:sa')
    {
        return date($format, $value);
    }

    /**
     * returns a printable version of the contents of the current session file
     *
     * @return string
     */
    public function returnPrintableSessionData()
    {
        if (is_readable($this->getFullPath())) {
            /** get content of file **/
            $serialized = file_get_contents($this->getFullPath());
    
            /**
             * for whatever reason, the unserializer breaks on periods in variable names, 
             * so we're going to replace it with a placeholder, then do our highlighting, etc.
             * then replace it back
             */
            $placeholder = chr(255); 
            $cleansed = str_replace('.', $placeholder, $serialized);
            $string = highlight_string(var_export($this->_unserialize_session_data($cleansed), true), true);
            $string = str_replace($placeholder, '.', $string);
        }
        else {
            $string = 'File not readable';
        }
            
        /** now send it all back **/
        return $string;
    }
    
    /**
     * Return human readable sizes
     *
     * @author      Aidan Lister <aidan@php.net>
     * @version     1.1.0
     * @link        http://aidanlister.com/repos/v/function.size_readable.php
     * @param       int    $size        Size
     * @param       int    $unit        The maximum unit
     * @param       int    $retstring   The return string format
     * @param       int    $si          Whether to use SI prefixes
     */
    public function size_readable($size, $unit = null, $retstring = null, $si = true)
    {
        // Units
        if ($si === true) {
            $sizes = array('B', 'kB', 'MB', 'GB', 'TB', 'PB');
            $mod   = 1000;
        } else {
            $sizes = array('B', 'KiB', 'MiB', 'GiB', 'TiB', 'PiB');
            $mod   = 1024;
        }
        $ii = count($sizes) - 1;
     
        // Max unit
        $unit = array_search((string) $unit, $sizes);
        if ($unit === null || $unit === false) {
            $unit = $ii;
        }
     
        // Return string
        if ($retstring === null) {
            $retstring = '%01.2f %s';
        }
     
        // Loop
        $i = 0;
        while ($unit != $i && $size >= 1024 && $i < $ii) {
            $size /= $mod;
            $i++;
        }
     
        return sprintf($retstring, $size, $sizes[$i]);
    }
    
    /**
     * Helps to unserialize session data
     * 
     * Got this originally from PHP manual
     * 
     * @link http://us2.php.net/manual/en/function.unserialize.php#44837
     * @return array
     */
    protected function _unserialize_session_data($serialized_string)
    {
        $variables = array();
        $a = preg_split("/(\w+)\|/", $serialized_string, -1, PREG_SPLIT_NO_EMPTY | PREG_SPLIT_DELIM_CAPTURE);
        for ($i = 0; $i < count($a); $i = $i+2) {
            $variables[$a[$i]] = unserialize($a[$i+1]);
        }
        return( $variables );
    }
    
}

class webpageDemoSessionBrowser extends SessionBrowser
{
    /**
     * get sortable by owner, accessed
     * 
     * Order by owner ID, then order by accessed... its possible that there might be exact same
     * accessed dates.
     * 
     * @return array
     */
    public function sortableByOwnerAccessed()
    {
        $sessions = array();
        
        foreach ($this as $file) {
            if ($file->isFile()) {
                $sessions[$file->getOwner()][$file->getATime()][] = array (
                                                                            'filename'=>$file->getFilename(),
                                                                            'fullpath'=>$file->getFullPath(),
                                                                            'accessed'=>$file->formatTime($file->getATime()),
                                                                            'modified'=>$file->formatTime($file->getMTime()),
                                                                            'changed' =>$file->formatTime($file->getCTime()),
                                                                            'owner'   =>$file->getOwner(),
                                                                            'group'   =>$file->getGroup(),
                                                                            'permissions'=>$file->getPerms(),
                                                                            'size'    =>$file->size_readable($this->getSize()),
                                                                            'data'    =>$file->returnPrintableSessionData()
                                                                          );
            }
        }
        
        return $sessions;
    }
}
?><html>
<head>
    <title>PHP Session Browser</title>
    <style type="text/css">
        fieldset, legend {
            border: 1px solid #99ccff;
            padding: 5px;
        }
        fieldset {
            margin-bottom: 20px;
        }
        legend {
            background-color: #dfefff;
            cursor: pointer;
        }
        
        table {
            border-collapse: collapse;
            border: 1px solid #cccccc;
        }
        table caption {
            font-weight: bold;
            background-color: #f4f4f4;
            text-align: left;
            padding: 5px;
            border-width: 1px 1px 0px 1px;
            border-color: #cccccc;
            border-style: solid;
        }
        table tr {
            background-color: #f9fcff;
        }
        table tr.alt {
            background-color: #eff9ff;
        }
        table td {
            padding: 5px;
        }
        table td.label {
            font-weight: bold;
            border-left: 1px solid #cccccc;
        }
        
        fieldset div {
            overflow: auto;
            display: none;
        }
    </style>
    <script type="text/javascript">
        function expandContract()
        {
            if (typeof(event) != 'undefined') {
                var sr = event.srcElement;
            }
            else if (this.parentNode) {
                var sr = this;
            }
            else {
                alert ("Need a compatible JS engine.");
                return false;
            }
            
            var divItem = sr.parentNode.getElementsByTagName('div');
            if (divItem[0].style.display=='block') {
                divItem[0].style.display='none';
            }
            else {
                divItem[0].style.display='block';
            }
        }
        
        function loadLegends()
        {
            var items = document.getElementsByTagName('legend');
            var ln = items.length;
            for (var i=0; i<ln; i++) {
                if (items[i].attachEvent) {
                    items[i].attachEvent('onclick', expandContract);
                }
                else {
                    items[i].addEventListener('click', expandContract, false);
                }
            }
        }
        
        window.onload=loadLegends;
    </script>
</head>
<body>
<?php
/**
 * get an iterator on the session save path
 */
$sessionFiles = new webpageDemoSessionBrowser();


/**
 * prepare and sort us a bunch of session data
 */
$sessions = $sessionFiles->sortableByOwnerAccessed();

/**
 * order by owner ascending
 */
ksort($sessions);

print "<h1>Session File Explorer</h1>";

/**
 * print out safemode
 */
print "<h2>Safe mode is " . ($sessionFiles->safeModeEnabled ? '' : 'not ') . "enabled.</h2>";

/**
 * print out directory
 */
print "<h2>Current Session Directory: {$sessionFiles->currentPath}</h2>";

/**
 * loop through each of the files
 */
foreach ($sessions as $owner=>$sessionArrayByOwner) {
    
    /**
     * print out the owner ID
     */
    print "<h3>Owner: {$owner}</h3>";
 
    /**
     * sort the modified items
     */
    krsort($sessionArrayByOwner);    
    
    foreach ($sessionArrayByOwner as $modifiedTimestamp=>$sessionArrayByAccessed) {
      
        foreach ($sessionArrayByAccessed as $session) {    
                
            /**
             * open up the info section
             */
            print "<fieldset>";
        
            /**
             * print our matrix of data
             */
            print "
                    <legend>
                    		<caption>{$session['filename']} - Accessed: {$session['accessed']}</caption>
                    </legend>
					<div>
                        <table>
                        	<caption>{$session['fullpath']}</caption>
                        	<tr>
                        		<td class='label'>Access:</td><td>{$session['accessed']}</td>
                        		<td class='label'>Modified:</td><td>{$session['modified']}</td>
                        		<td class='label'>Changed:</td><td>{$session['changed']}</td>
                        	</tr>
                        	<tr class='alt'>
                        		<td class='label'>Owner:</td><td>{$session['owner']}</td>
                        		<td class='label'>Group:</td><td>{$session['group']}</td>
                        		<td class='label'>Permissions:</td><td>{$session['permissions']}</td>
                        	</tr>
                        	<tr>
                        		<td class='label'>Size:</td><td colspan='5'>{$session['size']}</td>
                        	</tr>
                        </table>
        		  ";
            
            /** print out content **/
            print $session['data'];
            
            print "</div></fieldset>";
        }
    }
}
?>
</body>
</html>
<?php
/**
 * The install script - does no filtering and very little validation
 * 
 * Yes, I HATE making install scripts
 */
if (!empty($_POST)) {

    $errors = array();
    
    /**
     * technically, only the host is required I guess?
     */
    if (empty($_POST['myhost'])) {
        $errors[] = 'A host is required.';
    }
    
    /**
     * try connecting to the db
     */
    if (empty($errors)) {
        @mysql_connect($_POST['myhost'],$_POST['myuser'], $_POST['mypass']) or $errors[] = mysql_error();
    }
    
    /**
     * try selecting db
     */
    if (empty($errors)) {
        @mysql_select_db($_POST['mydb']) or $errors[] = mysql_error();
    }

    /**
     * if no errors, attempt to create the file
     */
    if (empty($errors)) {
        $fileString = "<?php\n/** configs set by user install **/\n";
        $fileString .= "config::set('mysqlHost', '{$_POST['myhost']}');\n";
        $fileString .= "config::set('mysqlUser', '{$_POST['myuser']}');\n";
        $fileString .= "config::set('mysqlPass', '{$_POST['mypass']}');\n";
        $fileString .= "config::set('mysqlDB', '{$_POST['mydb']}');\n";
        
        @file_put_contents('settings.php', $fileString) or $errors[] = 'Unable to write file settings.php';
    }
    
    /**
     * if no errors, we were able to write out the settings, so lets create the
     * tables and add the info.
     * 
     * I'm going to make the assumption they can create tables... bad I know.
     * Version 1.1 ;)
     */
    if (empty($errors)) {
        $username = 'timeadmin';
        $password = 'time$$clock44';
        $sql = array();
        $sql[] = "CREATE TABLE `employees` (`id` int(10) unsigned NOT NULL auto_increment,`status` char(1) NOT NULL,`firstName` varchar(64) NOT NULL,`lastName` varchar(64) NOT NULL,`dateAdded` int(10) unsigned NOT NULL, PRIMARY KEY  (`id`)) ENGINE=InnoDB";
        $sql[] = "CREATE TABLE `timeclock` (`id` int(10) unsigned NOT NULL auto_increment,`status` varchar(45) NOT NULL,PRIMARY KEY  (`id`)) ENGINE=InnoDB";
        $sql[] = "CREATE TABLE `timesheets` (`id` int(10) unsigned NOT NULL auto_increment,`employeeID` int(10) unsigned NOT NULL,`action` char(1) NOT NULL,`actionTime` datetime NOT NULL,`status` char(1) NOT NULL,PRIMARY KEY  (`id`)) ENGINE=InnoDB";
        $sql[] = "CREATE TABLE `users` (`id` int(10) unsigned NOT NULL auto_increment,`username` varchar(45) NOT NULL,`password` varchar(45) NOT NULL,`name` varchar(255) NOT NULL,PRIMARY KEY  (`id`)) ENGINE=InnoDB";
        $sql[] = "INSERT INTO `users` (username, password, name) VALUES ('{$username}', '" . md5($password) . "', 'Timeclock Admin')";

        foreach ($sql as $s) {
            mysql_query($s) or $error[] = mysql_error();
        }
        
        $url = "<a href='/manage'>/manage</a>";
    }
    
    /**
     * if no errors, must be success
     */
    if (empty($errors)) {
        $success = true;
    }
}
?>
<html>
    <head>
        <title>102 Degrees - Timetracker - Install</title>
        <link href="main.css" type="text/css" rel="stylesheet" media="all" />
        <!--[if IE]>
            <link href="iefix.css" type="text/css" rel="stylesheet" media="all" />
        <![endif]-->
    </head>
    <body style="margin-left: 20px">
        <h1>Timetracker Installation</h1>
        <?php
            if (empty($success)) {
        ?>
        <p>
            This script will help Install the Timetracker on your system.
        </p>
        <p>
            <strong>MySQL Credentials</strong>
        </p>
        <?php
            if (!empty($errors)) {
                print '<strong style="color: red">There was an error:<br />';
                foreach ($errors as $error) {
                    print $error . '<br />';
                }
                print '</strong>';
            }                
        ?>
        <p>
            In order to keep the employee's information, the MySQL credentials 
            are needed.  Please enter them below:
        </p>
        <form method="post" action="install.php">
            <ul>
                <li><input name="myhost" value="localhost" />MySQL Host Name</li>
                <li><input name="myuser" />MySQL User Name</li>
                <li><input name="mypass" type="password" />MySQL Password</li>
                <li><input name="mydb" />MySQL Database</li>
            </ul>
            <input type="submit" value="Install" />
        </form>
        <?php
            } else {
        ?>
            <h2>Success!</h2>
            <p>The script has been installed.  Please delete this file: install.php</p>
            <p>You may login with the following information:</p>
            <ul>
                <li>Username: <?php echo $username; ?></li>
                <li>Password: <?php echo $password; ?></li>
                <li>URL: <?php echo $url; ?></li>
            </ul>
        <?php
            }
        ?>
    </body>
</html>
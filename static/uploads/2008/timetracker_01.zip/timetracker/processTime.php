<?php
/**
 * processes the AJAX request
 */

/**
 * error display stuff
 */
require_once 'includes/config.php';

/**
 * get the timetracking item
 */
require_once 'includes/timeTracker.php';
$tracker = new timeTracker();

/**
 * validate the request and print it out
 */
print $tracker->processClockRequest($_POST);

?>
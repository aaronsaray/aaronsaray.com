<?php
require_once 'includes/config.php';
?>
<html>
    <head>
        <title>102 Degrees - Timetracker</title>
        <link href="main.css" type="text/css" rel="stylesheet" media="all" />
        <!--[if IE]>
            <link href="iefix.css" type="text/css" rel="stylesheet" media="all" />
        <![endif]-->
        <script type="text/javascript" src="/js/prototype.js"></script>
        <script type="text/javascript" src="/js/scriptaculous.js" ></script>
        <script type="text/javascript" src="/js/main.js"></script>
    </head>
    <body id="body">
        <div id="header"><a href="http://www.102degrees.com">102 Degrees TimeTracker - Version 1.0</a></div>
        <div id="messages"><br /><br />
            <div id="submitMessage"></div>
        </div>
        <div id="clock">
            <div id="timer"></div>
            <select name="employee" id="employee" onchange="checkSubmit();" onkeyup="checkKeyPress(event);">
                <option value="">- Select One -</option>
                <?php
                    /**
                     * get all the options here
                     */
                     require_once 'includes/timeTracker.php';
                     
                     $tracker = new timeTracker();
                     
                     try {
                        $employees = $tracker->getEmployees(timeTracker::ORDEREMPLOYEEFIRSTNAME, timetracker::GETTIMECLOCKSTATUS);
                     
                         foreach ($employees as $employee) {
                            print "<option value=\"{$employee['id']}:{$employee['clockStatus']}\">" . htmlentities($employee['fullName']) . "</option>\n";
                         }
                     }
                     catch (exception $e) {
                        print "<option value=\"\">There was an error</option>";
                     }
                ?>
            </select>
            <div class="explanation"><strong>&uarr;</strong> Up Arrow</div>
            <div class="explanation"><strong>&darr;</strong> Down Arrow</div>
            <br style="clear: both" />
            <input id="submitbutton" type="submit" onclick="submitTimeClock()" value="Select One" disabled="true" />
            <img src="/images/ajaxindicator.gif" alt="indicator" id="indicator" />
        </div>
        <div id="extra">
            <a href="/change.php">
                <img src="/images/caution.png" alt="caution" />
                <em>Click Here</em> if you've forgotten to clock in/out.
            </a>           
        </div>
        <script type="text/javascript">
            window.onload = function(){
                $('body').style.backgroundImage='none';
                setInterval("updateTime()", 100);
                checkSubmit();
                $('employee').focus();
            };
        </script>
    </body>
</html>
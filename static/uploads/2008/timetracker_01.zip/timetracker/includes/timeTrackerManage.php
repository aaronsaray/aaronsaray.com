<?php
/***********************************************************************************************
 * TimeTrackerManage Class
 * 
 * This is the Management Class for the timetracker
 *
 *
 * @author Aaron Saray <aaron@102degrees.com>
 **********************************************************************************************/

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/timeTracker.php';

/**
 * TimeTrackerManage Class
 * 
 * The management class for the timetracker
 * 
 * @package TimeTracker
 */
class timeTrackerManage extends timeTracker
{
    /**
     * returns whether the user is logged in or not
     *
     * @return boolean
     */
    public function loggedIn()
    {
        $this->_sessionManage();
        
        if (empty($_SESSION['username'])) {
            return false;
        }
        else {
            return true;
        }
    }
    
    /**
     * get history of the current user
     * 
     * @return array
     */
    public function getPendingHistory($values)
    {
        $data = array();

        /**
         * this probably could be done better.
         */
        $sql = "SELECT t.*, e.firstName, e.lastName FROM timesheets t inner join employees e on e.id=t.employeeID where t.status='P' and t.id=" . intval($values['id']);
        
        $query = mysql_query($sql, $this->_db);
        
        if (mysql_num_rows($query)) {
            /**
             * get values
             */
            $pointer = mysql_fetch_array($query);
        }
        else {
            // this should never happen
            die("failure.");
        }
        
        /**
         * ok - now we have the items in $pointer
         */
        $employeeID = $pointer['employeeID'];
        $actionTime = $pointer['actionTime'];

        /**
         * get the previous 2
         */
        $sql = "select * from timesheets where actionTime < '{$actionTime}' and employeeID={$employeeID} and status != 'D' order by actionTime desc limit 2";

        $query = mysql_query($sql, $this->_db);
        
        if (mysql_num_rows($query)) {
            
            /**
             * get them and put them into data
             */
            $temp = array();
            while ($row = mysql_fetch_array($query)) {
                $temp[] = $row;
            }
            /** need to reverse show it fits in the array correctly **/
            $i = count($temp) -1;
            for ($j=$i; $j>=0; $j--) {
                $data[] = $temp[$j];
            }
        }
        
        /**
         * now add in the current one as null
         */
        $data[] = NULL;
        
        /**
         * get thenext
         */
        $sql = "select * from timesheets where actionTime > '{$actionTime}' and status != 'D' order by actionTime asc limit 2";
        $query = mysql_query($sql, $this->_db);
        
        if (mysql_num_rows($query)) {
            while ($row = mysql_fetch_array($query)) {
                $data[] = $row;
            }
        }
        
        return $data;
    }
    
    /**
     * get the pending item
     * 
     * @return mixed
     */
    public function getPendingItem($values)
    {
        $this->_getDB();
        
        $sql = "SELECT t.*, e.firstName, e.lastName FROM timesheets t inner join employees e on e.id=t.employeeID where t.status='P' and t.id=" . intval($values['id']);
        
        $query = mysql_query($sql, $this->_db);
        
        if (mysql_num_rows($query)) {
            /**
             * get values
             */
            return mysql_fetch_array($query);
        }
        else {
            return false;
        }
    }
    
    /**
     * process pending
     * 
     * @param array $values posted values
     */
    public function processPending($values)
    {
        $error = '';
        
        if (empty($values['actionTime'])) {
            $error = 'A time is needed.';
        }
        else {
            if (strtotime($values['actionTime']) == 0) {
                $error = "Invalid date format.";
            }
        }
        
        /**
         * not a lot of error checking
         */
        
        if (!empty($error)) {
            $_SESSION['pendingError'] = $error;
            return false;
        }
        else {
            $actionTime = date('Y-m-d H:i:s', strtotime($values['actionTime']));
            
            $this->_getDB();
            
            $sql = "update timesheets set action='{$values['action']}', status='{$values['status']}', actionTime='{$actionTime}' where id=" . intval($values['id']);

            mysql_query($sql, $this->_db);
            $_SESSION['successMessage'] = 'Pending item was processed.';
            
            return true;
        }
        
    }
    
    /**
     * check for pending values
     * 
     * @return mixed
     */
    public function checkForPending()
    {
        $this->_getDB();
        
        $sql = "SELECT t.*, e.firstName, e.lastName FROM timesheets t inner join employees e on e.id=t.employeeID where t.status='P'";
        
        $query = mysql_query($sql, $this->_db);
        
        if (mysql_num_rows($query)) {
            $return = array();
            while ($row = mysql_fetch_array($query)) {
                $return[] = $row;
            }
            return $return;
        }
        else {
            return false;
        }
        
    }
    
    /**
     * generate report
     * 
     * @return boolean
     */
    public function generateReport($values)
    {
        $error = '';
        
        if (empty($values['startDate'])) {
            $error = 'Enter a start date.';
        }
        else {
            if (!preg_match("/^(\d{2})\/(\d{2})\/(\d{4})$/", $values['startDate'], $matches)) {
                $error = "Invalid date format, please use MM/DD/YYYY";
            }
            else {
                 if (!checkdate($matches[1], $matches[2], $matches[3])) {
                     $error = "Invalid Start Date.";
                 }
            }
        }
        

        if (empty($values['endDate'])) {
            $error = 'Enter an end date.';
        }
        else {
            if (!preg_match("/^(\d{2})\/(\d{2})\/(\d{4})$/", $values['endDate'], $matches2)) {
                $error = "Invalid date format, please use MM/DD/YYYY";
            }
            else {
                 if (!checkdate($matches2[1], $matches2[2], $matches2[3])) {
                     $error = "Invalid End Date.";
                 }
            }
        }
        
        
        /**
         * see if start is date is greater than end date
         */
        if (strtotime($values['startDate']) > strtotime($values['endDate'])) {
            $error = "Start date must be before end date.";
        }
        
        
        if (!empty($error)) {
            $_SESSION['startDate'] = $values['startDate'];
            $_SESSION['endDate'] = $values['endDate'];
            $_SESSION['generateError'] = $error;
            return false;
        }
        
        
        /**
         * generate the query
         */
        $dateStart = date("Y-m-d", strtotime($values['startDate']));
        $dateEnd = date("Y-m-d", strtotime($values['endDate']));
        
        $this->_getDB();
        
        $sql = "SELECT t.action, t.actionTime, t.employeeID, e.firstName, e.lastName FROM timesheets t inner join employees e on e.id=t.employeeID where t.status='A' and actionTime between '{$dateStart}' and '{$dateEnd}' order by actionTime";
        $query = mysql_query($sql, $this->_db);
        
        $xls = '';
        
        /**
         * times is keyed by employeeid
         * typeCounts is keyed bye employeeiD
         */
        $times = array();
        $typeCounts = array();
        $employee = array();
        
        if (mysql_num_rows($query)) {
            $xls = "First Name,LastName,Action,Date\n";
            $action = array('I'=>'Clock In', 'O'=>'Clock Out');
            while ($row = mysql_fetch_array($query)) {
                /**
                 * add on to each result
                 */
                $xls .= "{$row['firstName']},{$row['lastName']},{$action[$row['action']]},";

                $time = date("m/d/Y H:i:s", strtotime($row['actionTime']));
                
                $xls .= "{$time}\n";
                
                /**
                 * add in time, count
                 */
                $employee[$row['employeeID']] = $row['firstName'] . ' ' . $row['lastName'];
                $times[$row['employeeID']][] = array('action'=>$row['action'], 'time'=>$row['actionTime']);
                if (!isset($typeCounts[$row['employeeID']][$row['action']])) $typeCounts[$row['employeeID']][$row['action']] = 0;
                $typeCounts[$row['employeeID']][$row['action']]++;
                
            }
            
            /**
             * now make sure that typeCounts line up
             */
            $error = '';
            foreach ($typeCounts as $id=>$c) {
                $clockIn = intval($c['I']);
                $clockOut = intval($c['O']);
                if ($clockIn > $clockOut) {
                    $error .= $employee[$id] . " has more clock ins than clock outs.";
                }
                elseif ($clockOut > $clockIn) {
                    $error .= $employee[$id] . " has more clock outs than clock ins.";
                }
            }
            
            if (!empty($error)) {
                die(print $error);
            }
            
            
            /**
             * if we got this far, we know that we can make totals
             */
            $totals = array();
            foreach ($times as $empid=>$actions) {
                $total = 0;
                $lastValue = '';
                foreach ($actions as $current) {
                    if ($current['action'] == 'I') {
                        $lastValue = $current['time'];
                    }
                    else {
                        /**
                         * if normal time
                         */
                        if (!config::get('use15MinuteRule')) {
                            $secs = strtotime($current['time']) - strtotime($lastValue);
                        }
                        else {
                            /** 15 minute rule **/
                            
                            /**
                             * figure out first 15 minute block
                             */
                            $minute = date('i', strtotime($lastValue));
                            $seconds = date('s', strtotime($lastValue));
                            $addMinutes = 0;
                            $subtractSeconds = $seconds;
                            
                            switch (true) {
                                case ($minute < 60 && $minute >= 53):
                                    $addMinutes = 60-$minute;
                                    break;
                                case ($minute < 53 && $minute >=45):
                                    $addMinutes = -($minute - 45);
                                    break;
                                    

                                case ($minute < 45 && $minute >= 38):
                                    $addMinutes = 45-$minute;
                                    break;
                                case ($minute < 38 && $minute >=30):
                                    $addMinutes = -($minute - 30);
                                    break;
                                    
                                    
                                case ($minute < 30 && $minute >= 23):
                                    $addMinutes = 30-$minute;
                                    break;
                                case ($minute < 23 && $minute >=15):
                                    $addMinutes = -($minute - 15);
                                    break;
                                    
                                    
                                case ($minute < 15 && $minute >= 8):
                                    $addMinutes = 15-$minute;
                                    break;
                                case ($minute < 8 && $minute >=0):
                                    $addMinutes = -($minute - 0);
                                    break;
                            }
                            
                            /**
                             * have add minutes and subtract seconds to do
                             */
                            $firstValue = strtotime($lastValue) - $subtractSeconds + ($addMinutes * 60);
                            

                            
                            
                            
                            
                            /**
                             * figure out first 15 minute block
                             */
                            $minute = date('i', strtotime($current['time']));
                            $seconds = date('s', strtotime($current['time']));
                            $addMinutes = 0;
                            $subtractSeconds = $seconds;
                            
                            switch (true) {
                                case ($minute < 60 && $minute >= 53):
                                    $addMinutes = 60-$minute;
                                    break;
                                case ($minute < 53 && $minute >=45):
                                    $addMinutes = -($minute - 45);
                                    break;
                                    

                                case ($minute < 45 && $minute >= 38):
                                    $addMinutes = 45-$minute;
                                    break;
                                case ($minute < 38 && $minute >=30):
                                    $addMinutes = -($minute - 30);
                                    break;
                                    
                                    
                                case ($minute < 30 && $minute >= 23):
                                    $addMinutes = 30-$minute;
                                    break;
                                case ($minute < 23 && $minute >=15):
                                    $addMinutes = -($minute - 15);
                                    break;
                                    
                                    
                                case ($minute < 15 && $minute >= 8):
                                    $addMinutes = 15-$minute;
                                    break;
                                case ($minute < 8 && $minute >=0):
                                    $addMinutes = -($minute - 0);
                                    break;
                            }
                            
                            /**
                             * have add minutes and subtract seconds to do
                             */
                            $secondValue = strtotime($current['time']) - $subtractSeconds + ($addMinutes * 60);
                            
                            
                            $secs = $secondValue - $firstValue;
                            
                        }
                        
                        $lastValue = '';
                        $total += $secs;
                    }
                }
                
                $totals[$empid] = $total;
            }
            
            /**
             * now add on to the xls
             */
            $xls .= "\n\nTotals:\n";
            
            foreach ($totals as $id=>$total) {
                /**
                 * generate display
                 */
                $display = $this->_timeFormat($total);
                
                
                $xls .= $employee[$id] . "," . $display . "\n";
            }
        
        }
        else {
            $xls = 'No results for this date range.';
        }

        $filename = "Time Report (" 
            . date('m-d-Y', strtotime($values['startDate']))
            . ' to '
            . date('m-d-Y', strtotime($values['endDate']))
            . ') (generated on '
            . date('m-d-Y H:i:s')
            . ').csv';

        header('Pragma: public');
        header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");                  // Date in the past   
        header('Last-Modified: '.gmdate('D, d M Y H:i:s') . ' GMT');
        header('Cache-Control: no-store, no-cache, must-revalidate');     // HTTP/1.1
        header('Cache-Control: pre-check=0, post-check=0, max-age=0');    // HTTP/1.1
        header ("Pragma: no-cache");
        header("Expires: 0");
        header('Content-Transfer-Encoding: none');
        header("Content-Disposition: attachment; filename=\"{$filename}\"");

        print $xls;
        
        return true;
    }
    
    /**
     * get employee specs
     * 
     * @param array $values the posted values
     * @return mixed
     */
    public function getEmployeeSpecs($values)
    {
        $this->_getDB();
        
        $sql = "select * from employees where id=" . intval($values['id']);

        $query = mysql_query($sql, $this->_db);
        
        if (mysql_num_rows($query)) {
            $result = mysql_fetch_array($query);
            return $result;
        }
        else {
            return false;
        }
    }
    
    /**
     * edit employee
     *
     * @param array $values the posted values
     */
    public function editEmployee($values)
    {
        $this->_sessionManage();
        
        $error = '';
        
        if (empty($values['firstName']) || empty($values['lastName'])) {
            $error = 'First and last name are required.';
        }
        if (empty($values['status']) || !in_array($values['status'], array('A', 'S', 'D'))) {
            $error = "Invalid status.";
        }
        if (empty($values['id'])) {
            $error = "Employee ID is missing.";
        }
        
        
        if (empty($error)) {
            
            /**
             * make the db conection to make sure this user doesn't already exist
             */
            $this->_getDB();
            
            $firstName = mysql_real_escape_string($values['firstName'], $this->_db);
            $lastName = mysql_real_escape_string($values['lastName'], $this->_db);
            
            $sql = "select * from employees where firstName='{$firstName}' and lastName='{$lastName}' and id != " . intval($values['id']);
            $query = mysql_query($sql, $this->_db);
            if (mysql_num_rows($query)) {
                $error = "This employee is already in the database with this name.";
            }
        }
        
        
        if ($error) {
            /** send out the error **/
            $_SESSION['employeeError'] = $error;
            return false;
        }
        else {
            
            $sql = "update employees set firstName='{$firstName}', lastName='{$lastName}', status='{$values['status']}' where id=" . intval($values['id']);

            mysql_query($sql, $this->_db);
            
            
            /**
             * true return
             */
            $_SESSION['successMessage'] = "{$values['firstName']} {$values['lastName']} was updated.";
            
            return true;
            
        }
        
        
    }
    
    /**
     * Add employee
     *
     * @param array $values The posted values
     */
    public function addEmployee($values)
    {
        $this->_sessionManage();
        
        $error = '';
        
        if (empty($values['firstName']) || empty($values['lastName'])) {
            $error = 'First and last name are required.';
        }
        if (empty($values['status']) || !in_array($values['status'], array('A', 'S'))) {
            $error = "Invalid status.";
        }
        
        if (empty($error)) {
            
            /**
             * make the db conection to make sure this user doesn't already exist
             */
            $this->_getDB();
            
            $firstName = mysql_real_escape_string($values['firstName'], $this->_db);
            $lastName = mysql_real_escape_string($values['lastName'], $this->_db);
            
            $sql = "select * from employees where firstName='{$firstName}' and lastName='{$lastName}'";
            $query = mysql_query($sql, $this->_db);
            if (mysql_num_rows($query)) {
                $error = "This employee is already in the database.";
            }
        }
        
        
        if ($error) {
            /** send out the error **/
            $_SESSION['employeeError'] = $error;
            return false;
        }
        else {
            
            $sql = "insert into employees (firstName, lastName, status, dateAdded) values('{$firstName}', '{$lastName}', '{$values['status']}', " . time() . ")";
            mysql_query($sql, $this->_db);
            
            $sql = "insert into timeclock (id, status) values (LAST_INSERT_ID(), 'O')";
            mysql_query($sql, $this->_db);
            
            /**
             * true return
             */
            $_SESSION['successMessage'] = "{$values['firstName']} {$values['lastName']} was added as an employee.";
            
            return true;
            
        }
        
        
    }
    
    /**
     * Determines if they're validate users
     * 
     * If not, sets an error in the session
     * otherwise logs them in.
     *
     * @param array $values the post values
     */
    public function validateLogin($values)
    {
        $this->_sessionManage();
        
        $this->_getDB();
        
        $username = mysql_real_escape_string($values['loginusername'], $this->_db);
        $password = mysql_real_escape_string($values['loginpassword'], $this->_db);

        $sql = "select * from users where username='{$username}' and password=md5('{$password}')";

        $query = mysql_query($sql, $this->_db) or die(mysql_error());
        
        if (mysql_num_rows($query)) {
            $result = mysql_fetch_array($query);
            $_SESSION['username'] = stripslashes($result['username']);
            $_SESSION['userid'] = $result['id'];
            $_SESSION['name'] = $result['name'];
            
            return true;
        }
        else {
            /** didn't find it **/
            $_SESSION['loginError'] = 'Username or password incorrect.';
            
            return false;
        }
        
        
    }
    
    /**
     * log the user out
     */
    public function logout()
    {
        $this->_sessionManage();
        
        unset($_SESSION);
        
        session_destroy();
    }
    
    /**
     * manages the session
     */
    protected function _sessionManage()
    {
        if (!isset($_SESSION)) {
            session_start();
        }
    }
    
    /**
     * time diff function modified from php.net
     *
     * @param unknown_type $diff
     * @param unknown_type $detailed
     * @param unknown_type $max_detail_levels
     * @param unknown_type $precision_level
     * @return unknown
     */
    protected function _timeFormat($diff,$detailed=false, $max_detail_levels=8, $precision_level='second'){
      
        # Set the periods of time
        $periods = array("second", "minute", "hour", "day", "week", "month", "year", "decade");
        $lengths = array(1, 60, 3600, 86400, 604800, 2630880, 31570560, 315705600);
    
        $prec_key = array_search($precision_level,$periods);
      
        # round diff to the precision_level
        $diff = round(($diff/$lengths[$prec_key]))*$lengths[$prec_key];
      
      
        # Go from decades backwards to seconds
        $time = "";
        for ($i = (sizeof($lengths) - 1); $i>0; $i--) {
            if($diff > $lengths[$i-1] && ($max_detail_levels > 0)) {        # if the difference is greater than the length we are checking... continue
                $val = floor($diff / $lengths[$i-1]);    # 65 / 60 = 1.  That means one minute.  130 / 60 = 2. Two minutes.. etc
                $time .= $val ." ". $periods[$i-1].($val > 1 ? 's ' : ' ');  # The value, then the name associated, then add 's' if plural
                $diff -= ($val * $lengths[$i-1]);    # subtract the values we just used from the overall diff so we can find the rest of the information
                if(!$detailed) { $i = 0; }    # if detailed is turn off (default) only show the first set found, else show all information
                $max_detail_levels--;
            }
        }
     
        # Basic error checking.
        if($time == "") {
            return "Error-- Unable to calculate time.";
        } else {
            return $time;
        }
    }    
    
    
}
 
?>
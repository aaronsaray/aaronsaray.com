<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';
?>
<html>
    <head>
        <title>102 Degrees - Timetracker - Manage</title>
        <link href="/main.css" type="text/css" rel="stylesheet" media="all" />
        <link href="/manage.css" type="text/css" rel="stylesheet" media="all" />
        <!--[if IE]>
            <link href="iefix.css" type="text/css" rel="stylesheet" media="all" />
        <![endif]-->
        <script type="text/javascript" src="/js/prototype.js"></script>
        <script type="text/javascript" src="/js/scriptaculous.js" ></script>
        <script type="text/javascript" src="/js/main.js"></script>
        <script type="text/javascript" src="/js/datepicker.js"></script>
        <link href="/datepicker.css" type="text/css" rel="stylesheet" media="all" />
    </head>
    <body id="">
        <div id="header"><a href="http://www.102degrees.com">102 Degrees TimeTracker - Version 1.0</a></div>
        <?php
            if (!empty($_SESSION['username'])) {
                print '<a id="logout" href="/manage/logout.process.php" title="Log Out"><img src="/images/x.png" alt="x" />Log Out</a>
                       <a id="manageHome" href="/manage" title="Manage Home"><img src="/images/home.png" alt="home" />Manage Home</a>
                        <h1>Manage Timetracker</h1>';
            }
        ?>
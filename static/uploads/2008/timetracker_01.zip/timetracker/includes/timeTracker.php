<?php
/***********************************************************************************************
 * TimeTracker Class
 * 
 * This is the main timetracker class
 *
 *
 * @author Aaron Saray <aaron@102degrees.com>
 **********************************************************************************************/

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/config.php';


/**
 * TimeTracker Class
 * 
 * The main logic of the timetracker class
 * 
 * @package TimeTracker
 */
class timeTracker
{
    /**
     * Database Connection
     * @var mixed
     */
    protected $_db = null;
    
    /**
     * Order constant value
     */                               
    const ORDEREMPLOYEEFIRSTNAME = 1;
    
    /**
     * get the timeclock status
     */
    const GETTIMECLOCKSTATUS = 1;
    
    /**************************************************************************/
    
    
    
    public function __construct()
    {
    }
    
    /**
     * Return employees
     * 
     * By default, returns employees who are active
     * 
     * @return array
     */
    public function getEmployees($order = NULL, $getStatus = NULL, $queryOnStatus = NULL)
    {
        $this->_getDB();

        if (!is_null($getStatus)) {
            /** means we have to get the timeclock status **/
            $fields = "e.*, c.status as clockStatus";
        }
        else {
            $fields = "e.*";
        }
        
        
        $sql = "select {$fields} from employees e ";
        
        if (!is_null($getStatus)) {
            $sql .= "inner join timeclock c on c.id=e.id "; 
        }
        
        if (is_null($queryOnStatus)) $sql .= "where e.status='A'";
        
        
        
        if (!is_null($order)) {
            switch ($order) {
                case self::ORDEREMPLOYEEFIRSTNAME:
                    $sql .= " order by firstName, lastName";
                    break;
            }
        }
        
        $query = mysql_query($sql, $this->_db);
        
        if (!$query) {
            throw new exception("Not able to query database.");
        }
        
        
        $results = array();
        
        /**
         * build in full name
         */
        while ($result = mysql_fetch_array($query)) {
            $results[] = array_merge($result, array('fullName'=>$result['firstName'] . ' ' . $result['lastName']));
        }
        
        return $results;
    }
    
    /**
     * process a change request from the user
     *
     * @param array $values the POST values
     * @return string The string that is sent to the request handler
     */
    public function processChangeRequest($values)
    {
        /**
         * check for errors
         */
        $employee = $this->_verifyClockRequest($values);
        if (!is_array($employee)) {
            return $employee;
        }
        
        /**
         * check for clock time
         */
        $return = $this->_verifyTimeRequest($values);
        if ($return !== TRUE) {
            return $return;
        }
        
        
        /**
         * now can edit the change
         */
        
        
        
        /**
         * now lets create the clock in date
         * 
         * notice - just in case a second is about to switch, we 
         * store the time
         */
        $currentTime = time();
        
        $clockStatus = $values['type'] == 'Clock In' ? 'I' : 'O';

        $timeEntered = gmdate('Y-m-d H:i:s', strtotime("{$values['date']} {$values['hour']}:{$values['minute']} {$values['ampm']}")+ (config::get('timeOffset') * 60*60));
        $friendlyDate = "{$values['date']} {$values['hour']}:{$values['minute']} {$values['ampm']}";
        
        /**
         * now add to the timesheet
         */
        $sql = "insert into timesheets (employeeID, action, actionTime, status) values ({$employee['id']}, '{$clockStatus}', '{$timeEntered}', 'P')";

        $query = mysql_query($sql, $this->_db);
        
        if (!$query) {
            return "error|" . 'there was an error updating this timeclock.';
        }
        
        
        
        /**
         * possibly change the clock in/out option here
         */
        $sql = "SELECT t.* FROM timesheets t where actionTime > '{$timeEntered}' and employeeID=" . intval($employee['id']);
        $query = mysql_query($sql, $this->_db);
        if (!mysql_num_rows($query)) {
            /** means we have to swap them out **/
            $sql = "select status from timeclock where id=" . intval($employee['id']);
            $query = mysql_query($sql);            
            $result = mysql_fetch_array($query);
            $status = ($result['status'] == 'I') ? 'O' : 'I'; 
            $sql = "update timeclock set status='{$status}' where id=" .  intval($employee['id']);
            mysql_query($sql);
        }
        
        
        /**
         * generate the message
         */
        $returnString = "success|{$employee['firstName']} {$employee['lastName']} has clocked ";
        $returnString .= ($clockStatus == 'I' ? 'in' : 'out') . " at {$friendlyDate} in PENDING mode.";

        return $returnString;
        
        
        
        
        
    }
    
    /**
     * This function processes a clock request from the ajax handler
     * 
     * @param array $values The post values
     * @return string The string that is sent to the browser
     */
    public function processClockRequest($values)
    {
        /**
         * check for errors
         */
        $employee = $this->_verifyClockRequest($values);
        if (!is_array($employee)) {
            return $employee;
        }
        
        /**
         * now lets create the clock in date
         * 
         * notice - just in case a second is about to switch, we 
         * store the time
         */
        $currentTime = time();
        $storeDate = gmdate('m-d-Y H:i:s', $currentTime);
        $friendlyDate = gmdate('m/d/Y h:i:s a', $currentTime + (config::get('timeOffset') * 60*60));
        
        $clockStatus = $values['type'] == 'Clock In' ? 'I' : 'O';
        
        $sql = "update timeclock set status='{$clockStatus}' where id={$employee['id']}";
        
        $query = mysql_query($sql, $this->_db);
        
        if (!$query) {
            return "error|" . 'there was an error updating this timeclock.';
        }
        
        /**
         * now add to the timesheet
         */
        $sql = "insert into timesheets (employeeID, action, actionTime, status) values ({$employee['id']}, '{$clockStatus}', NOW(), 'A')";
        $query = mysql_query($sql, $this->_db);
        
        if (!$query) {
            return "error|" . 'there was an error updating this timeclock.';
        }
        
        
        
        /**
         * generate the message
         */
        $returnString = "{$employee['id']}:{$clockStatus}|{$employee['firstName']} {$employee['lastName']} has clocked ";
        $returnString .= ($clockStatus == 'I' ? 'in' : 'out') . " at {$friendlyDate}";

        return $returnString;
        
    }
    
    /**
     * verifies time
     * 
     * only returns one error cuz I'm lazy
     * 
     * @param array $values the POST values
     * @return mixed
     */
    protected function _verifyTimeRequest($values)
    {
        if (empty($values)) {
            $error = 'no values were sent.';
        }
        else {
            //date, hour, minute, ampm
            if (empty($values['date'])) {
                $error = 'Please sent a date.';
            }
            else {
                if (!preg_match("/^(\d{2})\/(\d{2})\/(\d{4})$/", $values['date'], $matches)) {
                    $error = "Invalid date format, please use MM/DD/YYYY";
                }
                else {
                     if (!checkdate($matches[1], $matches[2], $matches[3])) {
                         $error = "Invalid Date.";
                     }
                }
            }
            
            /**
             * check hour 
             */
            if (empty($values['hour'])) {
                $error = "Please send an hour.";
            }
            else if ($values['hour'] < 1 || $values['hour'] > 12) {
                $error = "Invalid hour.";
            }
            
            
            /**
             * check minute 
             */
            if ($values['minute'] == '') {
                $error = "Please send a minute.";
            }
            else if ($values['minute'] < 0 || $values['minute'] > 59) {
                $error = "Invalid minute.";
            }
            
            
            /**
             * ampm
             */
            if (empty($values['ampm'])) {
                $error = "Please select am or pm";
            }
            else if ($values['ampm'] != 'am' && $values['ampm'] != 'pm') {
                $error = "Invalid am pm value.";
            }
            
        }
        
        if (!empty($error)) {
            return "error|" . $error;
        }
        else {
            return true;
        }
        
        
    }
    
    /**
     * verify data sent in to create a login request
     * 
     * only returns one error because i'm lazy
     * 
     * @param array $values the POST values
     * @return mixed
     */
    protected function _verifyClockRequest($values)
    {
        /**
         * just in case someone submited here or surfed here
         */
        if (empty($values)) {
            $error = 'no values were sent';
        }
        else {
            /**
             * make sure the values are set
             */
            if (empty($values['employee'])) {
                $error = 'No employee sent.';        
            }
            if (empty($values['type'])) {
                $error = 'No type sent.';
            }
            else {
                if ($values['type'] != 'Clock In' && $values['type'] != 'Clock Out') {
                    $error = 'Invalid type sent:' . $values['type'];
                }
            }
        }
        
        
        /**
         * ok - if there is an error so fall, send that bakc
         */
        if (!empty($error)) {
            return "error|" . $error;
        }
        
        /**
         * time to connect to the db and make sure the user is valid
         */
        $this->_getDB();
        
        $sql = "select e.*, c.status as clockStatus from employees e 
                inner join timeclock c on c.id=e.id where e.status='A' 
                and e.id=" . intval($values['employee']);
        
        $query = mysql_query($sql, $this->_db);
        
        if (!$query) {
            $error = 'Error finding employee.';
        }
        else {
        
            $employee = mysql_fetch_array($query);
            
            /**
             * now we have to determine that if they're clocked in, 
             * we don't allow them to clock in and vice versa
             */
            if ($values['type'] == 'Clock Out' && $employee['clockStatus'] == '0') {
                $error = 'Employee already clocked out';
            }
            if ($values['type'] == 'Clock In' && $employee['clockStatus'] == 'I') {
                $error = 'Employee already clocked in';
            }
        }
        
        
        /**
         * check for errors again
         */
        if (!empty($error)) {
            return "error|" . $error;
        }
        else {
            return $employee;
        }
    }
    
    
    /**
     * used to get the database and store it locally
     */
    protected function _getDB()
    {
        if (is_null($this->_db)) {
            $this->_db = mysql_connect(config::get('mysqlHost'),config::get('mysqlUser'), config::get('mysqlPass'));
            if (!is_resource($this->_db)) {
                throw new exception(mysql_error()); 
            }
            
            $db = mysql_select_db(config::get('mysqlDB'));
            if (!$db) {
                throw new exception(mysql_error());
            }
        }
    }
}
 
?>
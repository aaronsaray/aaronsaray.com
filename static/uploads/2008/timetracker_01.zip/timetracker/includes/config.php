<?php
/**
 * The configuration class
 */

/**
 * The configuration class
 * 
 * Set the values here
 */
class config
{
    
    /**
     * mysql credentials
     */
    private static $mysqlHost = '';
    private static $mysqlUser = '';
    private static $mysqlPass = '';
    private static $mysqlDB   = '';
    
    /**
     * time offset
     * 
     * Central time is -6
     */
    private static $timeOffset = -6;
    
    /**
     * do the 15 minute calculation?
     * 7 or less = 0
     * 8 or more = 15
     */
    private static $use15MinuteRule = true;
    
    
    /**
     * Gets the config options
     *
     * @param string $name
     * @return mixed
     */
    public static function get($name)
    {
        if (isset(self::$$name)) {
            return self::$$name;
        }
        else {
            throw new exception ("Value of '{$name}' is not defined in config.");
        }
    }
    
    /**
     * sets config values
     *
     * @param string $name
     * @param string $value
     */
    public static function set($name, $value)
    {
        self::$$name = $value;
    }
}

/**
 * bring in the user settings
 */
if (!file_exists('settings.php')) die(header("Location: install.php"));
if (file_exists('install.php')) die (print "Please delete install.php!");
require 'settings.php';
?>
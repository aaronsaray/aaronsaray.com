/**
 * time generation function
 */
function updateTime()
{
    var clock = $('timer');
    
    var time = new Date();
    
    var innerTxt = '';

    /**
     * generate day
     */
    var days = ['Sun', 'Mon', 'Tues', 'Wed', 'Thur', 'Fri', 'Sat'];
    innerTxt += '<span>' + days[time.getDay()] + '</span> ';
    
    /**
     * generate hour min sec
     */
    var hours = time.getHours();
    var ampm = 'am';
    if (hours > 12) {
        hours = hours - 12;
        ampm = 'pm';
    }
    if (hours == 12) {
        ampm = 'pm';
    }
    if (hours == 24) {
        ampm = 'am';
    }
    
    var minutes = time.getMinutes();
    if (minutes < 10) {
        minutes = '0' + minutes;
    }
    
    var seconds = time.getSeconds();
    if (seconds < 10) {
        seconds = '0' + seconds;
    }
    
    innerTxt += hours + ':' + minutes + ':' + seconds + ' ' + ampm + ' ';
    
    /**
     * generate month/day/year
     */
    innerTxt += '<span>' + (time.getMonth()+1) + '/' + time.getDate() + '/' + time.getFullYear() + '</span>';
    
    /**
     * set 
     */
    clock.innerHTML = innerTxt;
}

/**
 * checks what to put for the input box
 */
function checkSubmit()
{
    var selectBox = $('employee');
    var inputButtonValue = '';
    var inputButtonDisable = true;
    var optionItem = 'i';
    
    if (selectBox.value == '') {
        /** nothing selected **/
       inputButtonValue = 'Select One';
       inputButtonDisable = true;
    }
    else {
        /** figure out whether to make it selectable or not **/
       var vals = selectBox.value.split(':');
       if (vals[1]=='I') {
           /** means clocked in **/
           inputButtonValue = 'Clock Out';
           inputButtonDisable = false;
           optionItem = 'o';
       }
       else {
           inputButtonValue = 'Clock In';
           inputButtonDisable = false;
           optionItem = 'i'
       }
    }
    
    /** now apply values **/
    if ($('submitbutton')) {
        $('submitbutton').value = inputButtonValue;
        $('submitbutton').disabled = inputButtonDisable;
    }
    if ($('submitbutton2')) {
        $('type' + optionItem).checked=true;
    }
}

function checkKeyPress(event)
{
    /** make sure we change the items first **/
    checkSubmit();
    
    /** 
     * now determine if it was enter
     */
    var keyCode = event.keyCode ? event.keyCode : event.which ? event.which : event.charCode;
    if (keyCode == 13 && $('employee').value != '') {
        submitTimeClock();
    }
}

/**
 * used to submit time
 */
function submitTimeClock()
{
    /**
     * disable submit and change value
     */
    var type = $('submitbutton').value;
    $('submitbutton').value='Submitting...';
    $('submitbutton').disabled='true';
    $('indicator').style.visibility='visible';

    /**
     * get employee ID
     */
    var emp = $('employee').value.split(':');
    var employeeID = emp[0];

    /**
     * build ajax request
     */
    var url = '/processTime.php';


    new Ajax.Request(url, {
        method: 'post',
        parameters: 'employee=' + employeeID + '&type=' + unescape(type),
        onSuccess: function(transport){
            timeclockSubmitSuccess(transport)
        },
        onFailure: function(transport){
            timeclockSubmitFailure(transport);
        }
        }
    );
}

/**
 * submit timeclock success
 * @param {Object} transport
 */
function timeclockSubmitSuccess(transport)
{
    /**
     * split this up - its the first value
     * The second value is for the message
     */
    var controls = transport.responseText.split("|");

    /**
     * make sure its not error
     */
    if (controls[0] == 'error') {
        timeclockSubmitFailure(transport);
    }

    /** set the value **/
    $('employee').options[$('employee').selectedIndex].value=controls[0];

    /** get rid of indicator **/
    $('indicator').style.visibility='hidden';
   
    /** show message **/
    $('submitMessage').innerHTML = controls[1];
    $('submitMessage').style.display='block';
    /** after 10 seconds **/
    clearTimeout(fadingMessageHandler);
    /** issue here that we could change items during fadeout.  oops**/
    fadingMessageHandler = setTimeout('fadeMessage()', 10000);
    
    /**
     * if we wanted to reset the select box here, we could 
     */
    
    /** call the main function again **/
    checkSubmit();
}

/**
 * used to fade out the message
 */
var fadingMessageHandler;
function fadeMessage()
{
    Effect.Fade('submitMessage', {duration: 6});    
}

/**
 * failure submitted timeclocks
 * @param {Object} transport
 */
function timeclockSubmitFailure(transport){
    var t = "There was an error.  Please report the error with this information:\n\n";
    t+= "responseText: " + transport.responseText + "\n";
    t+= "status: " + transport.status + "\n";
    t+= "statusText: " + transport.statusText + "\n";
    alert(t);
} 

/**
 * function to submit change
 */
function submitChange()
{
    /** make sure employee selected **/
    if ($('employee').value == '') {
        setErrorMessage('Please select an employee');
        return false;
    } 
    
    /**
     * check date
     */
    if (!checkDate()) {
        return false;
    }
    
    /**
     * check to make sure hour is selected
     */
    if ($('hour').value == '') {
        setErrorMessage("Select an hour");
        return false;
    }
    
    
    /**
     * they were successful now ajax it
     */
    $('submitbutton2').value='Submitting...';
    $('submitbutton2').disabled='true';
    $('indicator').style.visibility='visible';

    /**
     * get employee ID, type
     */
    var emp = $('employee').value.split(':');
    var employeeID = emp[0];
    
    var type='';
    if ($('typei').checked) {
        type='Clock In';
    }
    if ($('typeo').checked) {
        type='Clock Out';
    }

    var dte = $('date').value;
    var hour = $('hour').value;
    var minute = $('minute').value;
    var ampm = $('ampm').value;


    /**
     * build ajax request
     */
    var url = '/processChange.php';


    new Ajax.Request(url, {
        method: 'post',
        parameters: 'date=' + dte + '&employee=' + employeeID + '&type=' + type + '&hour=' + hour + '&minute=' + minute + '&ampm=' + ampm,
        onSuccess: function(transport){
            changeSubmitSuccess(transport)
        },
        onFailure: function(transport){
            changeSubmitFailure(transport);
        }
        }
    );
}


/**
 * handle the change success ajax request
 */
function changeSubmitSuccess(transport)
{
    /**
     * split this up - its the first value
     * The second value is for the message
     */
    var controls = transport.responseText.split("|");

    /**
     * make sure its not error
     */
    if (controls[0] == 'error') {
        changeSubmitFailure(transport);
    }
    
    
    /**
     * show change done screen
     */
    changeDone(controls[1]);
}

/**
 * handles when its done
 * @param {Object} text
 */
function changeDone(text)
{
    $('changeSuccessMessage').style.display='block';
    $('changeSuccessMessage').innerHTML = text;
    $('submitbutton2').value="Submitted!";
    $('indicator').style.display='none';
    $('employee').disabled=true;
    $('typei').disabled=true;
    $('typeo').disabled=true;
    $('hour').disabled=true;
    $('minute').disabled=true;
    $('ampm').disabled=true;
    $('date').disabled=true;
    setTimeout("window.location.href='/';", 10000);
}


/**
 * handle failure
 */
function changeSubmitFailure(transport)
{
    var t = "There was an error.  Please report the error with this information:\n\n";
    t+= "responseText: " + transport.responseText + "\n";
    t+= "status: " + transport.status + "\n";
    t+= "statusText: " + transport.statusText + "\n";
    alert(t);
}

/**
 * used to check for the valid date
 */
function checkDate()
{
    var dateArray = new Array();
    
    if ($('date')) {
        dateArray[0] = $('date').value;
    }
    else {
        dateArray[0] = $('startDate').value;
        dateArray[1] = $('endDate').value;
    }
     
    var dateStr = '';   
    var datePat = /^(\d{2})(\/|-)(\d{2})(\/|-)(\d{4})$/;

    for (var i=0; i < dateArray.length; i++) {
        dateStr = dateArray[i];
        
        var matchArray = dateStr.match(datePat); // is the format ok?
        if (matchArray == null) {
            setErrorMessage('Invalid date format - use MM/DD/YYYY');
            return false;
        }
        
        var day = matchArray[3]; // p@rse date into variables
        var month = matchArray[1];
        var year = matchArray[5];
        
        if (month < 1 || month > 12) { // check month range
            setErrorMessage('Invalid month');
            return false;
        }
        
        if (day < 1 || day > 31) {
            setErrorMessage("Invalid Day.");
            return false;
        }
        
        if ((month == 4 || month == 6 || month == 9 || month == 11) && day == 31) {
            setErrorMessage("Month does not have 31 days");
            return false;
        }
        
        if (month == 2) { // check for february 29th
            var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
            if (day > 29 || (day == 29 && !isleap)) {
                setErrorMessage("February " + year + " doesn't have " + day + " days.");
                return false;
            }
        }
    }
    
    unsetErrorMessage();
    return true; // date is valid
}    

function unsetErrorMessage()
{
    $('errorMessage').style.display='none';
}

/**
 * set the error message
 */
function setErrorMessage(error)
{
    $('errorMessage').style.display='block';
    $('errorMessage').innerHTML = error;
}


function checkGenerate()
{
    return checkDate();
}

<?php
require_once 'includes/config.php';
?>
<html>
    <head>
        <title>102 Degrees - Timetracker</title>
        <link href="main.css" type="text/css" rel="stylesheet" media="all" />
        <!--[if IE]>
            <link href="iefix.css" type="text/css" rel="stylesheet" media="all" />
        <![endif]-->
        <script type="text/javascript" src="/js/prototype.js"></script>
        <script type="text/javascript" src="/js/scriptaculous.js" ></script>
        <script type="text/javascript" src="/js/main.js"></script>
        <script type="text/javascript" src="/js/datepicker.js"></script>
        <link href="datepicker.css" type="text/css" rel="stylesheet" media="all" />
    </head>
    <body id="body">
        <div id="header"><a href="http://www.102degrees.com">102 Degrees TimeTracker - Version 1.0</a></div>
        <h1>Submit TimeTracker Change</h1>
        <div id="changePanel">
            <div class="panel">
                <label for="employee">Choose Your Name:</label>
                <select name="employee" id="employee" onchange="checkSubmit();" onkeyup="checkSubmit()">
                    <option value="">- Select One -</option>
                    <?php
                        /**
                         * get all the options here
                         */
                         require_once 'includes/timeTracker.php';
                         
                         $tracker = new timeTracker();
                         
                         try {
                            $employees = $tracker->getEmployees(timeTracker::ORDEREMPLOYEEFIRSTNAME, timetracker::GETTIMECLOCKSTATUS);
                         
                             foreach ($employees as $employee) {
                                print "<option value=\"{$employee['id']}:{$employee['clockStatus']}\">" . htmlentities($employee['fullName']) . "</option>\n";
                             }
                         }
                         catch (exception $e) {
                            print "<option value=\"\">There was an error</option>";
                         }
                    ?>
                </select>
            </div>
            <div class="panel">
                <label for="type">What didn't happen?</label>
                <span class="typeSpan"><input type="radio" name="type" id="typei" value="Clock In" checked="checked" />Clock In</span>
                <span class="typeSpan"><input type="radio" name="type" id="typeo" value="Clock Out" />Clock Out</span>
            </div>     
            <div class="panel smallPanel">
                <label>When?</label>
                <input type="textbox" name="date" id="date" maxlength="10" onchange="checkDate()" /> (mm/dd/yyyy)
            </div>
            <div class="panel smallPanel">
                <label>&nbsp;</label>
                <select name="hour" id="hour">
                    <option value=""> - </option>
                    <option value="01">01</option>
                    <option value="02">02</option>
                    <option value="03">03</option>
                    <option value="04">04</option>
                    <option value="05">05</option>
                    <option value="06">06</option>
                    <option value="07">07</option>
                    <option value="08">08</option>
                    <option value="09">09</option>
                    <option value="10">10</option>
                    <option value="11">11</option>
                    <option value="12">12</option>
                </select>
                <span id="delim">:</span>
                <select name="minute" id="minute">
                    <option value="00">00</option>
                    <option value="05">05</option>
                    <option value="10">10</option>
                    <option value="15">15</option>
                    <option value="20">20</option>
                    <option value="25">25</option>
                    <option value="30">30</option>
                    <option value="35">35</option>
                    <option value="40">40</option>
                    <option value="45">45</option>
                    <option value="50">50</option>
                    <option value="55">55</option>
                </select>
                &nbsp;&nbsp;
                <select name="ampm" id="ampm">
                    <option value="am">AM</option>
                    <option value="pm">PM</option>
                </select>
            </div>
            <div class="panel smallPanel">
                <div id="errorMessage"></div>
            </div>
            <div class="panel">
                <input type="submit" id="submitbutton2" value="Submit Change" onclick="submitChange()" />
                <img src="/images/ajaxindicator.gif" alt="indicator" id="indicator" />
            </div>        
            <a href="/" title="Cancel">Cancel</a>
        </div>
        <div id="changeSuccessMessage"></div>
        <script type="text/javascript">
            window.onload = function(){
                $('body').style.backgroundImage='none';
                var dpck   = new DatePicker({
                                            relative  : 'date',
                                            language  : 'en',
                                            keepFieldEmpty: true,
                                            topOffset: 40,
                                            showDuration: 0.3,
                                            enableCloseOnBlur: true,
                                            disableFutureDate: false,
                                            dateFormat: [ ["mm", "dd", "yyyy"], "/" ]
                                            });
            };
        </script>
    </body>
</html>
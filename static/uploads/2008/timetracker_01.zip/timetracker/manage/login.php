<?php

/**
 * check auth
 */
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/timeTrackerManage.php';

$tracker = new timeTrackerManage();

if ($tracker->loggedIn()) {
    die(header("Location: /manage/index.php"));
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/manageTop.php';

?>
        <div id="login">
            <img src="/images/lock.png" />
            <fieldset>
                <legend>Log In</legend>
                <form action="login.process.php" method="post">
                    <input type="text" name="loginusername" id="loginusername" /><br /><br />
                    <input type="password" name="loginpassword" id="loginpassword" /> 
                    <input type="submit" value="Log In" id="loginbutton" /><br /><br />
                    <?php
                        if (!empty($_SESSION['loginError'])) {
                            print "<div id=\"loginerror\">{$_SESSION['loginError']}</div>";
                            unset($_SESSION['loginError']);
                        }
                    ?>
                </form>
            </fieldset>
        </div>
<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/manageBottom.php';
?>
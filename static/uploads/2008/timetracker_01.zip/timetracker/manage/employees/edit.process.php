<?php
/**
 * check auth
 */
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/timeTrackerManage.php';

$tracker = new timeTrackerManage();

if (!$tracker->loggedIn()) {
    die(header("Location: /manage/login.php"));
}

if ($tracker->editEmployee($_POST)) {
    die(header("Location: /manage"));
}
else {
    die(header("Location: /manage/employees/edit.php?id={$_POST['id']}"));
}

?>
<?php
/**
 * check auth
 */
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/timeTrackerManage.php';

$tracker = new timeTrackerManage();

if (!$tracker->loggedIn()) {
    die(header("Location: /manage/login.php"));
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/manageTop.php';

?>
<div id="manageEmployee">
    <fieldset>
        <legend><img src="/images/person.png" alt="person" /><br />Add Employee<br /><br /></legend>
        <form action="add.process.php" method="post">
            <label for="firstName">First Name:</label><input type="text" id="firstName" name="firstName" />
            <label for="lastName">Last Name:</label><input type="text" id="lastName" name="lastName" />
            <label for="status">Status:</label>
            <select id="status" name="status">
                <option value="A">Active</option>
                <option value="S">Suspended</option>
            </select>
            <label for="employeeSubmit"></label><input type="submit" id="employeeSubmit" value="Submit Employee" />
            <?php
                if (!empty($_SESSION['employeeError'])) {
                    print "<div class=\"error\">{$_SESSION['employeeError']}</div>";
                    unset($_SESSION['employeeError']);
                }
            ?>  
        </form>
    </fieldset>
</div>

<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/manageBottom.php';
?>
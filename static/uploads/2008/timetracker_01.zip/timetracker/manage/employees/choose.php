<?php
/**
 * check auth
 */
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/timeTrackerManage.php';

$tracker = new timeTrackerManage();

if (!$tracker->loggedIn()) {
    die(header("Location: /manage/login.php"));
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/manageTop.php';

?>
<div id="manageEmployee">
    <fieldset>
        <legend><img src="/images/person.png" alt="person" /><br />Edit Employee<br /><br /></legend>
        <form action="choose.process.php" method="post">
            <label for="firstName">Choose Employee:</label>
            <select id="id" name="id">
                <?php
                    $employees = $tracker->getEmployees(timeTracker::ORDEREMPLOYEEFIRSTNAME, NULL, TRUE);
                    foreach ($employees as $employee) {
                        print "<option value=\"{$employee['id']}\">{$employee['firstName']} {$employee['lastName']}</option>";
                    }
                    
                ?>
            </select>
            <label for="employeeSubmit"></label><input type="submit" id="employeeSubmit" value="Choose Employee" />
            <?php
                if (!empty($_SESSION['employeeError'])) {
                    print "<div class=\"error\">{$_SESSION['employeeError']}</div>";
                    unset($_SESSION['employeeError']);
                }
            ?>  
        </form>
    </fieldset>
</div>

<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/manageBottom.php';
?>
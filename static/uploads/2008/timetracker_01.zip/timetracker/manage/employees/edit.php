<?php
/**
 * check auth
 */
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/timeTrackerManage.php';

$tracker = new timeTrackerManage();

if (!$tracker->loggedIn()) {
    die(header("Location: /manage/login.php"));
}

$employee = $tracker->getEmployeeSpecs($_GET['id']);
$employee = array_map('stripslashes', $employee);

if (!$employee) {
    die(header("Location: /manage/employees/choose.php"));
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/manageTop.php';

 

?>
<div id="manageEmployee">
    <fieldset>
        <legend><img src="/images/person.png" alt="person" /><br />Edit Employee: <?php echo $employee['firstName'], ' ', $employee['lastName']; ?><br /><br /></legend>
        <form action="edit.process.php" method="post">
            <label for="firstName">First Name:</label><input type="text" id="firstName" name="firstName" value="<?=$employee['firstName']?>" />
            <label for="lastName">Last Name:</label><input type="text" id="lastName" name="lastName" value="<?=$employee['lastName']?>" />
            <label for="status">Status:</label>
            <select id="status" name="status">
            <?php
                $statuses = array('A'=>'Active', 'S'=>'Suspended', 'D'=>'Deleted');
                foreach ($statuses as $status=>$desc) {
                    print "<option value=\"{$status}\" ";
                    if ($status == $employee['status']) {
                        print "selected='selected'";
                    }
                    print ">{$desc}</option>";
                }
            ?>
            </select>
            <input type="hidden" name="id" value="<?=$employee['id']?>" />
            <label for="employeeSubmit"></label><input type="submit" id="employeeSubmit" value="Submit Employee" />
            <?php
                if (!empty($_SESSION['employeeError'])) {
                    print "<div class=\"error\">{$_SESSION['employeeError']}</div>";
                    unset($_SESSION['employeeError']);
                }
            ?>  
        </form>
    </fieldset>
</div>

<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/manageBottom.php';
?>
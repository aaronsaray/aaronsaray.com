<?php
/**
 * check auth
 */
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/timeTrackerManage.php';

$tracker = new timeTrackerManage();

if (!$tracker->loggedIn()) {
    die(header("Location: /manage/login.php"));
}

$id = $tracker->getEmployeeSpecs($_POST);

if ($id) {
    die(header("Location: /manage/employees/edit.php?id={$id['id']}"));
}
else {
    die(header("Location: /manage/employees/choose.php"));
}

?>
<?php
/**
 * check auth
 */
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/timeTrackerManage.php';

$tracker = new timeTrackerManage();

if (!$tracker->loggedIn()) {
    die(header("Location: /manage/login.php"));
}

if (!$tracker->generateReport($_POST)) {
    die(header("Location: /manage/generateTimeReport.php"));
}
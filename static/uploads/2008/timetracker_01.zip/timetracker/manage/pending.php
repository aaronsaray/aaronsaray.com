<?php
/**
 * check auth
 */
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/timeTrackerManage.php';

$tracker = new timeTrackerManage();

if (!$tracker->loggedIn()) {
    die(header("Location: /manage/login.php"));
}


$data = $tracker->getPendingItem($_GET);

if (!$data) {
    die(header("Location: /manage"));
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/manageTop.php';

$data['actionTime'] = date('m/d/Y h:i:s a', strtotime($data['actionTime']));

?>
<div id="timeReport">
    <fieldset>
        <legend><img style="height: 64px; width: 64px" src="/images/caution.png" alt="clock" /><br />Process Pending Item<br /><br /></legend>
        <form action="pending.process.php" method="post" onsubmit="return checkPendingProcess()">
            <label>Person:</label><input type="text" disabled="disabled" value="<?=$data['firstName'];?> <?=$data['lastName'];?>" />
            <label for="actionTime">Action Time:</label><input type="text" id="actionTime" name="actionTime" value="<?=$data['actionTime'];?>" /><span>MM/DD/YYYY HH:MM:SS AM</span>
            <label for="action">Clock In/Out:</label><select name="action" id="action">
            <?php
                /**
                 * show the clock in out
                 */
                $action = array('I'=>'Clock In', 'O'=>'Clock Out');
                foreach ($action as $a=>$desc) {
                    print "<option value='{$a}' ";
                    if ($a == $data['action']) print "selected='selected'";
                    print ">{$desc}</option>";
                }
            ?>
            </select>
            <label for="status">Status:</label><select name="status" id="status">
            <option value='A'>Active</option>
            <option value='D'>Delete</option>
            </select>
            <label for="generateSubmit"></label><input type="submit" id="generateSubmit" value="Submit Report" />
            <?php
                print "<div class='error'' id='errorMessage'";
                if (!empty($_SESSION['pendingError'])) {
                    print " style='display: block'>";
                    print $_SESSION['pendingError'];
                    unset($_SESSION['pendingError']);
                }
                else {
                    print ">";
                }
            ?>  
            </div>
            <input type="hidden" name="id" value="<?=$data['id'];?>" />
        </form>
    </fieldset>
    <br />
    <fieldset>
        <legend><?=$data['firstName'];?> <?=$data['lastName'];?> History</legend>
        <ul>
            <?php
                $history = $tracker->getPendingHistory($_GET);
                
                foreach ($history as $item) {
                    if (is_null($item)) {
                        $output = 'Current Item.';
                    }
                    else {
                        $output = "{$data['firstName']} {$data['lastName']} clocked ";
                        if ($item['action'] == "I") {
                            $output .= "in";
                        }
                        else {
                            $output .= "out";
                        }
                        $output .= " at ";
                        /** figure time **/
                        $output .= date('m/d/Y h:i:s a', strtotime($item['actionTime']));
                        
                        if ($item['status'] == 'P') {
                            $output .= "(in pending mode)";
                        }
                    }
                    print "<li>{$output}</li>";
                }
            
            ?>
        </ul>
    </fieldset>
</div>
<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/manageBottom.php';
?>
<?php
/**
 * check auth
 */
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/timeTrackerManage.php';

$tracker = new timeTrackerManage();

if (!$tracker->loggedIn()) {
    die(header("Location: /manage/login.php"));
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/manageTop.php';


?>
<div id="successMessagePanel">
<?php
if (!empty($_SESSION['successMessage'])) {
    print "<div id='submitMessage'>{$_SESSION['successMessage']}</div>";
    unset($_SESSION['successMessage']);
    
    /** yes its  hacky **/
    print "<script type='text/javascript'>
            fadingMessageHandler = setTimeout('fadeMessage()', 10000);
            </script>";
    
}
?>
</div>
<?php

/**
 * check for pending
 */
$pending = $tracker->checkForPending();
if ($pending) {
    print "
            <div class='managePanel'>
            <img src='/images/caution.png' alt='caution' style='height: 64px; width: 64px' />
            <h3>Pending Requests</h3>
          ";
    
    foreach ($pending as $item) {
        print "<a href='/manage/pending.php?id={$item['id']}'>{$item['firstName']} {$item['lastName']} for {$item['actionTime']}</a><br />";
    }
    
    print "<br /></div>";
}
?>

<div class="managePanel">
    <img src="/images/clock.png" alt="clock" />
    <h3>Generate Time Report</h3>
    <a href="/manage/generateTimeReport.php" title="Generate Time Report">Click here 
    to generate a time report</a>.<br /><br />
</div>

<div class="managePanel">
    <img src="/images/person.png" alt="person" />
    <h3>Manage Employees</h3>
    <a href="/manage/employees/add.php" title="Add Employee">Add an Employee</a><br />
    <a href="/manage/employees/choose.php" title="Edit Employee">Edit an Employee</a><br />
</div>    


<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/manageBottom.php';
?>
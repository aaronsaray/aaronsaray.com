<?php

/**
 * check auth
 */
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/timeTrackerManage.php';

$tracker = new timeTrackerManage();

if ($tracker->loggedIn()) {
    die(header("Location: /manage/index.php"));
}

if ($tracker->validateLogin($_POST)) {
    die(header("Location: /manage/index.php"));
}
else {
    die(header("Location: /manage/login.php"));
}

?>
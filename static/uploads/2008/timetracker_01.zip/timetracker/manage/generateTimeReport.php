<?php
/**
 * check auth
 */
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/timeTrackerManage.php';

$tracker = new timeTrackerManage();

if (!$tracker->loggedIn()) {
    die(header("Location: /manage/login.php"));
}

require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/manageTop.php';

if (isset($_SESSION['startDate'])) {
    $startDate = $_SESSION['startDate'];
    unset($_SESSION['startDate']);
}
else {
    $startDate = '';
}
if (isset($_SESSION['endDate'])) {
    $endDate = $_SESSION['endDate'];
    unset($_SESSION['endDate']);
}
else {
    $endDate = '';
}

?>
<div id="timeReport">
    <fieldset>
        <legend><img src="/images/clock.png" alt="clock" /><br />Generate Time Report<br /><br /></legend>
        <form action="generateTimeReport.process.php" method="post" onsubmit="return checkGenerate()">
            <label for="startDate">Start Date:</label><input type="text" id="startDate" name="startDate" value="<?=$startDate;?>" /><span>MM/DD/YYYY</span>
            <label for="endDate">End Date:</label><input type="text" id="endDate" name="endDate" value="<?=$endDate;?>" /><span>MM/DD/YYYY</span>
            <label for="generateSubmit"></label><input type="submit" id="generateSubmit" value="Submit Report" />
             
            <?php
                print "<div class='error'' id='errorMessage'";
                if (!empty($_SESSION['generateError'])) {
                    print " style='display: block'>";
                    print $_SESSION['generateError'];
                    unset($_SESSION['generateError']);
                }
                else {
                    print ">";
                }
            ?>  
            </div>
        </form>
    </fieldset>    
</div>
<script type="text/javascript">
    window.onload = function(){
        var dpck   = new DatePicker({
                                    relative  : 'startDate',
                                    language  : 'en',
                                    keepFieldEmpty: true,
                                    topOffset: 30,
                                    showDuration: 0.3,
                                    enableCloseOnBlur: true,
                                    disableFutureDate: false,
                                    dateFormat: [ ["mm", "dd", "yyyy"], "/" ]
                                    });
        var dpck2  = new DatePicker({
                                    relative  : 'endDate',
                                    language  : 'en',
                                    keepFieldEmpty: true,
                                    topOffset: 30,
                                    showDuration: 0.3,
                                    enableCloseOnBlur: true,
                                    disableFutureDate: false,
                                    dateFormat: [ ["mm", "dd", "yyyy"], "/" ]
                                    });

    };
</script>
<?php
require_once $_SERVER['DOCUMENT_ROOT'] . '/includes/manageBottom.php';
?>
<?php 
/*******************************************************************************
 * Admin Form View
 * 
 * This is the form that the admin uses to change elgg dev tools options
 * 
 * @package OHT
 * @subpackage ElggDevTools
 * @author Aaron Saray (102degrees.com)
 ******************************************************************************/

echo '<div class="contentWrapper">';
echo '<p>' . elgg_echo('OHT_ElggDevTools:formexplanation') . '</p>';

/******************** build form *******************************/

/** delete views **/
$form_body = "<fieldset><legend>" . elgg_echo('OHT_ElggDevTools:OHTlegend') . "</legend>";
$form_body .= '<p>' . elgg_echo('OHT_ElggDevTools:OHTexplanation') . '</p>';

$form_body .= "<p><h3>" . elgg_echo('OHT_ElggDevTools:deleteviews:question') . "</h3>";
$value = (int) datalist_get('OHT_ElggDevTools:deleteviews');
$form_body .= elgg_view('input/radio', array('value'=>$value, 'internalname'=>'deleteviews', 'options'=>array(elgg_echo('OHT_ElggDevTools:deleteviews:answer:yes')=>1, elgg_echo('OHT_ElggDevTools:deleteviews:answer:no')=>0)));
$form_body .= '<em>' . elgg_echo('OHT_ElggDevTools:deleteviews:explanation') . '</em></p>';
/** end delete views **/

/** firephp **/
$form_body .= '<p><h3>' . elgg_echo('OHT_ElggDevTools:enablefirephp:question') . '</h3>';
$value = (int) datalist_get('OHT_ElggDevTools:enablefirephp');

/** helper - see if fire php extension is installed - sometimes is wrong - drat **/
if ($value) {
    if (class_exists('FirePHP')) {
        $fb = FirePHP::getInstance(TRUE);
        if (!$fb->detectClientExtension()) {
            $form_body .= '<em class="error" id="firephperror">' . elgg_echo('OHT_ElggDevTools:enablefirephp:warning') . '</em><br />';
        }
    } 
}

$form_body .= elgg_view('input/radio', array('value'=>$value, 'internalname'=>'enablefirephp', 'options'=>array(elgg_echo('OHT_ElggDevTools:enablefirephp:answer:yes')=>1, elgg_echo('OHT_ElggDevTools:enablefirephp:answer:no')=>0)));
$form_body .= '<em>' . elgg_echo('OHT_ElggDevTools:enablefirephp:explanation') . '</em></p>';
/** end firephp **/


$form_body .= '</fieldset><br />';
$form_body .= '<fieldset><legend>' . elgg_echo('OHT_ElggDevTools:Defaultlegend') . '</legend>';
$form_body .= '<p>' . elgg_echo('OHT_ElggDevTools:Defaultexplanation') . '</p>';

$form_body .= "<p><h3>" . elgg_echo('OHT_ElggDevTools:simplecache:question') . "</h3>";
$value = $vars['config']->simplecache_enabled;
$form_body .= elgg_view('input/radio', array('value'=>$value, 'internalname'=>'usesimplecache', 'options'=>array(elgg_echo('OHT_ElggDevTools:simplecache:answer:yes')=>1, elgg_echo('OHT_ElggDevTools:simplecache:answer:no')=>0)));
$form_body .= '<em>' . elgg_echo('installation:simplecache:description') . '</em></p>';

$form_body .= '</fieldset>';

$form_body .= elgg_view('input/submit', array('value'=>elgg_echo('OHT_ElggDevTools:formbutton')));

echo elgg_view('input/form', array('body'=>$form_body, 'action'=>$CONFIG->wwwroot . 'action/OHT_ElggDevTools/updatesettings', 'internalid'=>'OHT_ElggDevTools_form'));

echo '</div>';
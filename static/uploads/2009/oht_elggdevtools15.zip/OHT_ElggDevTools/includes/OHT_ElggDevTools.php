<?php
/*******************************************************************************
 * Elgg Dev Tools Main Logic
 * 
 * This page holds the Elgg Dev Tools Main Logic class
 * 
 * @package OHT
 * @subpackage ElggDevTools
 * @author Aaron Saray (102degrees.com)
 ******************************************************************************/

/**
 * Elgg Dev Tools Main Logic 
 * 
 * This holds the logic for the plugin for the hacky stuff I want to do
 * 
 * @package OHT
 * @subpackage ElggDevTools
 */
class OHT_ElggDevTools 
{
    /**
     * Launcher executes functionality on plugin init  
     * 
     * Launcher is responsible for querying the settings and running anything
     * that is demanded to run intially.
     */
    public static function launcher()
    {
        /** delete views if its requested **/
        $delete = datalist_get('OHT_ElggDevTools:deleteviews');
        if ($delete) self::_deleteViews();
        
        /** include firePHP if need be **/
        $firephp = datalist_get('OHT_ElggDevTools:enablefirephp');
        if ($firephp) {
            require_once dirname(__FILE__) . '/firephp/FirePHP.class.php';
            require_once dirname(__FILE__) . '/firephp/fb.php';
        }
        else {
            require_once dirname(__FILE__) . '/FirePHPDisabled.php';
        }
    }
    
    /**
     * Deletes View Cache
     */
    protected static function _deleteViews()
    {
        elgg_get_filepath_cache()->delete('view_paths');
    }    
}
?>
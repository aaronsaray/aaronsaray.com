<?php
/*******************************************************************************
 * The Admin Options Index Page
 * 
 * THis shows a form to update all of the plugin development tools you may need.
 * 
 * @package OHT
 * @subpackage ElggDevTools
 * @author Aaron Saray (102degrees.com)
 ******************************************************************************/

/** elgg engine **/
require_once(dirname(dirname(dirname(__FILE__))) . "/engine/start.php");

/** admin settings **/
admin_gatekeeper();
set_context('admin');

/**
 * get content
 */
$title = elgg_view_title(elgg_echo('OHT_ElggDevTools:Title'));
$body = elgg_view('OHT_ElggDevTools/index');

/** and draw **/
page_draw(elgg_echo('OHT_ElggDevTools:Title'), elgg_view_layout("two_column_left_sidebar", '', $title . $body));
?>
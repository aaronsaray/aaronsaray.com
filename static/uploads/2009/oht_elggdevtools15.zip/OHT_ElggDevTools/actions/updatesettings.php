<?php
/*******************************************************************************
 * Update Elgg Dev Tools Setttings
 * 
 * This applies the changes from the Elgg admin form.  Normally, you would dev
 * with a bit more security for default settings - but I'm assuming you - the dev
 * kinda know what you're doing
 * 
 * @package OHT
 * @subpackage ElggDevTools
 * @author Aaron Saray (102degrees.com)
 ******************************************************************************/

/** make sure admin **/
action_gatekeeper();

/** delete views **/
datalist_set('OHT_ElggDevTools:deleteviews', get_input('deleteviews'));

/** enable firephp **/
datalist_set('OHT_ElggDevTools:enablefirephp', get_input('enablefirephp'));

/** enable/disable simple cache **/
if (get_input('usesimplecache')) {
    elgg_view_enable_simplecache();
} else {
    elgg_view_disable_simplecache();
}

/** set update message and redirect cuz we're done **/
system_message(elgg_echo("OHT_ElggDevTools:message:successfulupdate"));
forward($CONFIG->wwwroot . 'pg/OHT_ElggDevTools');
<?php
require 'phpinicreator_htmlview.class.php';
$pic = phpIniCreator::getInstance();

$view = new phpIniCreator_htmlview($pic);

print $view->returnError();

?>
<form action="initial.process.php" method="post">
	Enter php.ini file:<br />
	<textarea name="ini"></textarea>
	<input type="submit" />
</form>

<?php
phpIniCreator::saveInstance($pic);
?>
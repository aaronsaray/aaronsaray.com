<?php
require 'phpinicreator_htmlview.class.php';
$pic = phpIniCreator::getInstance();

$view = new phpIniCreator_htmlview($pic);

?><html>
<head>
	<style type="text/css">
		body {
			background-color: #fff;
			color: #000;
			font-family: verdana;
			font-size: 12px;
		}
		table {
			border-collapse:  collapse;
			margin-bottom: 20px;
			width: 100%;
		}
		caption {
			text-align: left;
			font-weight: bold;
		}
		td {
			font-size: 12px;
			font-family: verdana;
			border: 1px solid;
			padding: 2px;
		}
		h1 {
			text-align: center;
		}
		h2 {
			background-color: #f4f4f4;
			border: 1px solid #ccc;
			padding: 10px;
		}
		
		table.matches {
			background-color: #efe;
		}
		table.matches td {
			border-color: #9f9;
		}
		table.notFoundOurs, table.notFoundYours {
			background-color: #ffe;
		}
		table.notFoundOurs td, table.notFoundYours td {
			border-color: #aa9;
		}
		table.yoursNotSuggested {
			background-color: #f99;
		}
		table.yoursNotSuggested {
			border-color: #fee;
		}
	</style>
</head>
<body>
	<h1>Initial Verification of PHP.ini</h1>
<?php
	print $view->returnPromptableOutput();
	phpIniCreator::saveInstance($pic);
?>
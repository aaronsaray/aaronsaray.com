<?php
class phpIniCreator
{
	const PHP_INI_XML_FILE = 'php.ini.xml';
	
	const INI_NOT_FOUND_IN_OURS = 1;
	const INI_NOT_FOUND_IN_YOURS = 2;
	const INI_YOURS_NOT_SUGGESTED = 3;
	const INI_MATCHES = 4;
	
	const ERROR_NO_POSTED_INI = 1;
	const ERROR_XML_FILE_NOT_FOUND = 2;
	
	protected $_originalIni = '';
	
	protected $_originalIniParsed = array();
	
	protected $_iniXMLFileValues = array();
	
	protected $_comparisonSet = array();
	
	protected $_modifiedContent = array();
	
	protected $_err = 0;
	
	public static function getInstance()
	{
		if (!isset($_SESSION)) session_start();
		return isset($_SESSION['phpinicreator']) ? $_SESSION['phpinicreator'] : new phpIniCreator();		
	}
	
	public static function saveInstance($pic)
	{
		$_SESSION['phpinicreator'] = $pic;
	}
	
	public function __construct()
	{
	}
	
	public function processModified($POST)
	{
		$this->_modifiedContent = $POST;
		return true;
	}
	
	public function generateDownload()
	{
		$return = ";;;php.ini file generated from php.ini creator\r\n";
		foreach ($this->_modifiedContent as $section=>$options) {
			$return .= "[{$section}]\r\n";
			foreach ($options as $directive=>$value) {
				$return .= "{$directive}={$value}\r\n";
			}
		}
		
		header("Content-Disposition: attachment; filename=php.ini");   
		header("Content-Type: application/force-download");
		header("Content-Type: application/octet-stream");
		header("Content-Type: application/download");
		header("Content-Description: File Transfer");            
		header("Content-Length: " . strlen($return));
		print $return;
	}
	
	public function processInitial($POST)
	{
		return $this->_verifyHasContent($POST) && $this->_generatePromptableContent();
	}
	
	protected function _verifyHasContent($POST)
	{
		if (!empty($POST['ini'])) {
			if (get_magic_quotes_gpc()) {
				$this->_originalIni = stripslashes($POST['ini']);
			}
			else {
				$this->_originalIni = $POST['ini'];
			}
			return true;
		}
		else {
			$this->_setError(self::ERROR_NO_POSTED_INI);
			return false;
		}
	}
	
	protected function _setError($err)
	{
		$this->_err = $err;
	}
	
	public function getError()
	{
		$return = $this->_err;
		unset($this->_err);
		return $return;
	}
	
	
	protected function _generatePromptableContent()
	{
		$return = $this->_initializeValues();
		if ($return) {
			$this->_parseOriginalIni();
			$this->_setComparison();
			return true;
		}
		else {
			return false;
		}
	}
	
	protected function _initializeValues()
	{
		if (is_readable(self::PHP_INI_XML_FILE)) {
			$xml = new DomDocument();
			$xml->preserveWhiteSpace = false;
			$xml->load(self::PHP_INI_XML_FILE);
			$sections = $xml->getElementsByTagName('section');
			
			foreach ($sections as $section) {
				foreach ($section->childNodes as $option) {
					$this->_iniXMLFileValues[$section->getAttribute('name')][] = array(
						'name'		=> $option->getElementsByTagName('name')->item(0)->nodeValue,
						'type'		=> $option->getElementsByTagName('type')->item(0)->nodeValue,
						'suggested'	=> $option->getElementsByTagName('suggested')->item(0)->nodeValue,
						'comment'	=> $option->getElementsByTagName('comment')->item(0)->nodeValue,
																		   			   );
				}
			}
			return true;
		}
		else {
			$this->_setError(self::ERROR_XML_FILE_NOT_FOUND);
			return false;
		}
	}
	
	protected function _parseOriginalIni()
	{
		$lines = explode("\n", $this->_originalIni);
		$section = 'PHP';
		
		while (list($key, $line) = each($lines)) {

			$line = trim($line);
			
			/**
			 * don't mess with blank lines
			 */
			if (empty($line)) continue;
			
			/**
			 * check for section
			 */
			if ($line{0} === '[') {
				$section = substr($line, 1, strpos($line, ']')-1);
				continue;
			}
			
			/**
			 * check for comment
			 */
			if ($line{0} === ';') continue;
			
			/**
			 * assuming this is a config option
			 */
			$parts = explode('=', $line);
			$this->_originalIniParsed[$section][trim($parts[0])] = trim($parts[1]);
		}
	}
	
	//goes through and compares the parsed ini to the 
	protected function _setComparison()
	{
		$tempItems = array();
		
		foreach ($this->_iniXMLFileValues as $section=>$items) {
			foreach ($items as $item) {
				$tempItems[$section][$item['name']]['comment'] = $item['comment'];
				$tempItems[$section][$item['name']]['type'] = $item['type'];
				$tempItems[$section][$item['name']]['MINE'] = $item['suggested'];
			}
		}
		foreach ($this->_originalIniParsed as $section=>$item) {
			foreach ($item as $directive=>$value) {
				$tempItems[$section][$directive]['YOURS'] = $value;
			}
		}
		
		foreach ($tempItems as &$directives) {
			foreach ($directives as &$directive) {
				// we will always have a comment
				if (!isset($directive['comment'])) {
					$directive['examined'] = self::INI_NOT_FOUND_IN_OURS;
					continue;
				}
				if (!isset($directive['YOURS'])) {
					$directive['examined'] = self::INI_NOT_FOUND_IN_YOURS;
					continue;
				}
				if ($directive['YOURS'] == $directive['MINE']) {
					$directive['examined'] = self::INI_MATCHES;
					continue;
				}
				$directive['examined'] = self::INI_YOURS_NOT_SUGGESTED;
			}
		}
		
		$this->_mainSet = $tempItems;
	}
	
	public function getMainSet()
	{
		return $this->_mainSet;
	}
}

?>
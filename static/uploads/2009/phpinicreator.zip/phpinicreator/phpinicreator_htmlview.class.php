<?php
require 'phpinicreator.class.php';

class phpIniCreator_htmlview
{
	const ERROR_NO_POSTED_INI = 'There was no content posted to be processed';
	
	const ERROR_CANNOT_LOCATE_XML_FILE = 'Unable to locate the php.ini.xml file';
	
	protected $_pic = null;
	
	public function __construct(phpIniCreator $pic)
	{
		$this->_pic = $pic;
	}
	
	public function returnPromptableOutput()
	{
	
		$return = '<p>You have submitted your PHP.ini file.  This script will review your file,
		compare it to our internal database, make suggestions, and compare our suggestions to
		your PHP file.  You will then have an option to export a new php.ini.</p>
		<form action="generate.process.php" method="post">';
		
		$mainSet = $this->_pic->getMainSet();
		
		
		
		foreach ($mainSet as $section=>$options) {
			$return .= "<h2>{$section}</h2>";
			foreach ($options as $directive=>$option) {
				
				$class = '';
				$message = '';
				$hiddenInput = '';
				
				switch ($option['examined']) {
					case phpIniCreator::INI_MATCHES:
						$class = 'matches';
						$message = 'This is the suggested setting.  Good job!';
						break;
					case phpIniCreator::INI_NOT_FOUND_IN_OURS:
						$class = 'notFoundOurs';
						$message = 'This setting was not found in our php.ini file.  Perhaps you have a newer version?';
						$hiddenInput = "<input type=\"hidden\" name=\"{$section}[{$directive}]\" value=\"{$option['YOURS']}\" />";
						break;
					case phpIniCreator::INI_NOT_FOUND_IN_YOURS:
						$class = 'notFoundYours';
						$message = 'We found this setting in our php.ini file but not in yours.';
						$hiddenInput = "<input type=\"hidden\" name=\"{$section}[{$directive}]\" value=\"{$option['OURS']}\" />";
						break;
					case phpIniCreator::INI_YOURS_NOT_SUGGESTED:
						$class = 'yoursNotSuggested';
						$message = 'Your php.ini file is not the suggested setting.';
						break;		
				}
				
				$return .= "<table class=\"{$class}\">";
				$return .= "<caption>{$directive}</caption>";
				if (!empty($option['comment'])) {
					$return .= "<tr><td colspan=\"2\" class=\"comment\">{$option['comment']}</td></tr>";
				}
				if (isset($option['MINE'])) {
					$return .= "<tr><td>Suggested:</td><td><strong>{$option['MINE']}</strong></td></tr>";					
				}
				if (isset($option['YOURS'])) {
					$return .= "<tr><td>Yours:</td><td>";
					$return .= $this->_generatePrompt($option['type'], "{$section}[{$directive}]", $option['YOURS']);
					$return .= "</td></tr>";					
				}
				$return .= "<tr><td colspan=\"2\" class=\"message\">{$message}{$hiddenInput}</td></tr>";
				
				$return .= "</table>";
			}

		}
		
		$return .='<input type="submit" value="Generate Ini File" /></form>';
	
		return $return;
	}
	
	protected function _generatePrompt($type, $name, $value)
	{
		$return = '';

		switch ($type) {
			case 'OnOff':
				$opts = array('On', 'Off');
				foreach ($opts as $opt) {
					$return .= "<input type=\"radio\" name=\"{$name}\" value=\"{$opt}\" ";
					$return .= $opt == $value ? 'checked="checked"' : '';
					$return .= " />{$opt} &nbsp;";
				}
				break;
				
			case 'Int':
				$return .= "<input type=\"text\" name=\"{$name}\" value=\"{$value}\" />";
				break;
				
			default:
				$return .= $value;
		}
		
		return $return;
	}
	
	public function returnError()
	{
		$return = '<div style="color: #f00; font-weight: bold">';

		$error = $this->_pic->getError();
		
		if ($error) {
			switch ($error) {
				case phpIniCreator::ERROR_NO_POSTED_INI:
					$return .= 'Please post your ini file.';
					break;
			}
		}
		
		$return .= '</div>';
		
		return $return;
	}
}
?>
<?php
require 'phpinicreator.class.php';
$pic = phpIniCreator::getInstance();
if ($pic->processModified($_POST)) {
	die($pic->generateDownload());
}
else {
	$location = 'initial.review.php';
}
phpIniCreator::saveInstance($pic);
die(header("Location: {$location}"));

?>
<?php
require 'phpinicreator.class.php';
$pic = phpIniCreator::getInstance();
if ($pic->processInitial($_POST)) {
	$location = 'initial.review.php';
}
else {
	$location = 'index.php';
}
phpIniCreator::saveInstance($pic);
die(header("Location: {$location}"));
?>
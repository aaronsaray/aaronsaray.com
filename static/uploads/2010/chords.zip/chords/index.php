<?php
#============================================================================
#	include fingerings
#============================================================================
include ("fingerings.php");
#============================================================================
#	set to G if no note passed
#============================================================================
if (!$_POST['note']){ $_POST['note'] = "G"; }
#============================================================================
#	generate select box options
#============================================================================
/*----- read in array -----*/
foreach($fingering as $key => $value){
	$select_options[] = $key;
}
/*----- remove dupes -----*/
$select_options = array_unique($select_options);
/*----- generate html -----*/
for ($i=0; $select_options[$i]; $i++){
	/*----- set class -----*/
	$main_notes[] = "A";
	$main_notes[] = "A#/Bb";
	$main_notes[] = "B";
	$main_notes[] = "C";
	$main_notes[] = "C#/Db";
	$main_notes[] = "D";
	$main_notes[] = "D#/Eb";
	$main_notes[] = "E";
	$main_notes[] = "F";
	$main_notes[] = "F#/Gb";
	$main_notes[] = "G";
	$main_notes[] = "G#/Ab";
	if (in_array ($select_options[$i], $main_notes)){
		$class = "class='main'";
	}
	else { $class=""; }
	/*----- add to html -----*/	
	$select .= "<option value='".$select_options[$i]."'";
	if ($_POST['note'] == $select_options[$i]){ $select .= " selected"; }
	$select .= " ".$class.">".$select_options[$i]."</option>\n";
}
#============================================================================
#	function to set tab
#============================================================================
function get_fingering($tab){
	global $fingering;
	/*----- break into array -----*/
	$parts = preg_split('//', $tab, -1, PREG_SPLIT_NO_EMPTY); 
	/*----- set omit strings -----*/
	for ($i=0; $i<6; $i++){
		$value = array_shift($parts);
		if ($value != 0){ $parts[5] = "x"; }
	}
	/*----- return array -----*/
	return $parts;
}
#============================================================================
#	function to print output
#============================================================================
function output_tab($tabs,$version){
	/*----- print guitar neck -----*/
	print "<img src='guitarneck.gif' width='545' height='100' style='position: absolute; top: ".(75 + ($version*125))."; left: 25; z-index: 2'>\n";
	/*----- print fingerings -----*/
	foreach ($tabs as $key => $value){
		print_fingering($key,$value,$version);
	}
}
#============================================================================
#	function to print fingering image
#============================================================================
function print_fingering($string,$position,$version){
	/*----- set height -----*/
	if ($string == 0){ $top = 147 + ($version*125); }
	if ($string == 1){ $top = 132 + ($version*125); }
	if ($string == 2){ $top = 117 + ($version*125); }
	if ($string == 3){ $top = 102 + ($version*125); }
	if ($string == 4){ $top = 88 + ($version*125); }
	if ($string == 5){ $top = 74 + ($version*125); }
	if ($string == 6){ $top = 60 + ($version*125); }
	/*----- set width -----*/
	if ($position < 1){ $left = 33 ; }
	if ($position == 1){ $left = 65 ; }
	if ($position == 2){ $left = 101 ; }
	if ($position == 3){ $left = 137 ; }
	if ($position == 4){ $left = 170 ; }
	if ($position == 5){ $left = 202 ; }
	if ($position == 6){ $left = 234 ; }
	if ($position == 7){ $left = 264 ; }
	if ($position == 8){ $left = 293 ; }
	if ($position == 9){ $left = 322 ; }
	if ($position == 10){ $left = 350 ; }
	if ($position == 11){ $left = 376 ; }
	if ($position == 12){ $left = 402 ; }
	/*----- print fingering -----*/
	if ($position == "x"){
		print "<img src='no.gif' style='position: absolute; top: ".$top."; left: ".$left.";  z-index: 5;'>\n";
	}
	else {
		print "<img src='finger.gif' style='position: absolute; top: ".$top."; left: ".$left.";  z-index: 5;'>\n";
	}
}
?>
<style>
	td.blank { 
		width: 10px; 
		height: 20px; 
		background-color: #ffffff;
		border: 1px solid black;
	}
	td.finger { 
		width: 10px; 
		height: 20px; 
		background-color: #000000;
		border: 1px solid #666666;
	}
	td.omit { 
		width: 10px; 
		height: 20px; 
		background-color: #cccccc;
		border: 1px solid #666666;
	}
	td.fret { 
		width: 10px; 
		height: 20px; 
		background-color: white;
		font-weight: bold;
		border: none;
	}
	option.main {
		background-color: #666666;
		color: #ffffff;
	}
</style>
<form action="index2.php" method="post" name="chordchange">
<table border="0" cellspacing="0" cellpadding="3">
  <tr>
    <td>
		<select name="note" onChange="document.chordchange.submit()">
			<?php print $select; ?>
      	</select>
	</td>
  </tr>
</table>
</form>

<?php
#============================================================================
#	get chord fingering for each version
#============================================================================
foreach ($fingering[$_POST['note']] as $key => $value){
	/*----- create array of finger positions -----*/
	$chord = get_fingering($value);
	/*----- print fingering for this version -----*/
	output_tab($chord,$key);
}
?>

<?php
/**
 * This page holds the hello world class
 */

/**
 * Hello world - version 2
 * 
 * This class outputs hello world using a template
 */
class helloWorld
{
	/**
	 * our template file name
	 * @var string
	 */
	const TEMPLATEFILENAME = 'helloWorld.html';
	
	/**
	 * our template replacement item
	 * @var string
	 */
	const TEMPLATEPLACEHOLDER = '[[replaceme]]';
	
	/**
	 * our processed template name
	 * @var string
	 */
	private $__template = '';
	
	/**
	 * constructor
	 * 
	 * makes our template file and checks to make sure it exists
	 */
	public function __construct()
	{
		$templateFileName = dirname(dirname(__FILE__)) . 
							DIRECTORY_SEPARATOR . 'templates' .
							DIRECTORY_SEPARATOR . self::TEMPLATEFILENAME;
		
		if (!file_exists($templateFileName)) {
			throw new exception($templateFileName . ' does not exist.');
		}
		else{
			$this->__template = $templateFileName;
		}
	}
	
	/**
	 * output function
	 * 
	 * This function reads in the template file, 
	 * swaps out the replacement, and returns the output
	 * 
	 * @return string
	 */
	public function output()
	{
		$string = file_get_contents($this->__template);
		$string = str_replace(self::TEMPLATEPLACEHOLDER, 'HELLO WORLD VERSION 2!!', $string);
		return $string;
	}
}
?>
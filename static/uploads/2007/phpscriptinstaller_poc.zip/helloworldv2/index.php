<?php
require 'includes/helloWorld.php';

$hw = new helloWorld();

echo $hw->output();

?>
<?php
/**
 * PHP Script Installer
 * 
 * Packager
 * 
 * This is a proof of concept for a PHP script installer
 * 
 * @author Aaron D Saray
 */

/****************************************************************************************
 * USER CONFIG VARIABLES HERE:
 ***************************************************************************************/

/**
 * the fully developed script could have an interactive path picker,
 * but here we're just hadsetting it to my proof of concept project
 */
$baseFolder = $_SERVER['DOCUMENT_ROOT'] . DIRECTORY_SEPARATOR . 'helloworldv2';

/**
 * the output file name - make sure this isn't the same name as a file in your
 * base directory, otherwise it won't be cool
 */
$outputFileName = 'pocinstall.php';


/****************************************************************************************
 * END USER CONFIG VARIABLES HERE:
 ***************************************************************************************/

/**
 * The rest of this script is what this packaging script would run after we
 * were ready to proceed with packaging our script.
 */






/**
 * include our main class 
 */
require 'class/phpScriptInstaller.php';

/**
 * get new instance
 */
$installer = new phpScriptInstaller();

try {
	/**
	 * set base folder
	 */
	$installer->setBaseFolder($baseFolder);
	
	/**
	 * set output file name
	 */
	$installer->setOutputFileName($outputFileName);
	
	/**
	 * do it
	 */
	$installer->createPackage();
	
	/**
	 * display the message
	 */
	print $baseFolder . DIRECTORY_SEPARATOR . $outputFileName . ' created successfully.';
}
catch (exception $e) {
	print 'There was an error: ' . $e->getMessage();
}
?>
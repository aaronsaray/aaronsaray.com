<?php
/**
 * PHP Script Installer
 * 
 * Proof of concept - template file.
 * 
 * 
 * @author Aaron D Saray
 */

/**
 * PHP script installer class
 * 
 * @author Aaron D Saray
 */
class installer
{
	/**
	 * creates directories
	 *
	 * @param array $directories
	 */
	public static function makeDirectories($directories)
	{
		foreach ($directories as $directory) {
			mkdir($directory);
		}
	}
	
	/**
	 * creates the files
	 * 
	 * @param array $files
	 */
	public static function makeFiles($files)
	{
		foreach ($files as $file) {
			file_put_contents($file['name'], base64_decode($file['content']));
		}
	}
}

/**
 * Directories to create
 */
[[directories]]


/**
 * files to create
 */
[[files]]


/**
 * create the directories and then the files
 */
installer::makeDirectories($directories);
installer::makeFiles($files);

print 'Done';
?>
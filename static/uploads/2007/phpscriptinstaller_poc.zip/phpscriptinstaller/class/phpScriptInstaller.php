<?php
/**
 * PHP Script Installer
 * 
 * This page holds the main class for this project.
 * 
 * This is a proof of concept for a PHP script installer
 * 
 * @author Aaron D Saray 
 */

/**
 * PHP Script Installer Class
 * 
 * This class takes care of processing all of the files inside of a directory,
 * and recursively, and packaging them all up into a file which is a self
 * installer for PHP
 */
class phpScriptInstaller
{
	/**
	 * base folder to start our file gathering ni
	 * @var string
	 */
	protected $_baseFolder = '';
	
	/**
	 * output file name
	 * @var string
	 */
	protected $_outputFileName = '';
	
	/***********************************************************************************/
	
	/**
	 * constructor
	 * 
	 * Currently, does nothing
	 */
	public function __construct()
	{}
	
	/**
	 * set base folder
	 * 
	 * checks for the base folder and sets it if it exists
	 * 
	 * @throws exception
	 * @param string $folder
	 */
	public function setBaseFolder($folder)
	{
		if (file_exists($folder)) {
			$this->_baseFolder = $folder;
		}
		else {
			throw new exception (__METHOD__ . 
								 ': "' . htmlentities($folder) . 
								 '" does not exist');
		}
	}
	
	/**
	 * set output file
	 * 
	 * This function sets the output file.  Will throw an exception if
	 * the file already exists or if we can't write to the location
	 * that we are trying to.  Right now, we're just writing to the basefolder,
	 * but we could extend this to write it anywhere I suppose if we wanted
	 * to.  but its only a proof of concept.
	 * 
	 * @throws exception
	 * @param string $file
	 */
	public function setOutputFileName($file)
	{
		/**
		 * first check to make sure we can write to basefolder
		 * (not perfect...but good enough for right now)
		 */
		if (!is_writable($this->_baseFolder)) {
			throw new exception (__METHOD__ . 
								 ': "' . htmlentities($folder) . 
								 '" is not writable');
		}
		
		/**
		 * make sure the file doesn't exist
		 */
		$outputFileName = $this->_baseFolder . DIRECTORY_SEPARATOR . $file;
		if (file_exists($outputFileName)) {
			throw new exception (__METHOD__ . 
								 ': "' . htmlentities($outputFileName) . 
								 '" already exists - unable to overwrite');
		}
		else {
			$this->_outputFileName = $outputFileName;
		}
	}
	
	/**
	 * Create the package for output
	 * 
	 * @throws exception
	 */
	public function createPackage()
	{
		/**
		 * make sure our stuff is set successfully first
		 */
		if (empty($this->_baseFolder)) {
			throw new exception (__METHOD__ . 
								 ': _baseFolder is not set.');
		}
		if (empty($this->_outputFileName)) {
			throw new exception (__METHOD__ . 
								 ': _outputFileName is not set.');
		}
		
		/**
		 * start traversing our directory
		 */
		$info = array();
		$this->_discover($this->_baseFolder, $info);
		
		/**
		 * parse for directories and files so I can make them later
		 * -- this may be redundant - but its only a PoC --
		 */
		$directories = array();
		$files = array();
		$this->_parse($info, $directories, $files);
		/**
		 * shift off the first one because its the '.'
		 */
		array_shift($directories);

		/**
		 * finally make the output file
		 */
		$this->_makeOutputFile($directories, $files);
	}
	
	
	/****************************************************************************/
	
	/**
	 * recursive function to gather our data together
	 * 
	 * @param $folder string
	 * @param $info array
	 * @param $path string
	 */
	protected function _discover($folder, &$info, $path = '.') 
	{
		/**
		 * get an iterator instance
		 */
		$directory = new DirectoryIterator($folder);
		
		/**
		 * loop through each
		 */
		foreach ($directory as $d) {
			
			/**
			 * we don't need to gather our dots
			 */
			if (!$d->isDot()) {
				/**
				 * if its a directory, restart our recursive iteration, but
				 * pass our info with our path key - so it gets nested correctly
				 */
				if ($d->isDir()) {
					$this->_discover($folder . '/' . $d->getFilename(), $info[$path], $path . '/' . $d->getFilename());
				}
				/**
				 * else, get the name of the file and its base64 encoded content
				 */
				else {
					$info[$path][] = array('name'=>$path . '/' . $d->getFilename(), 'content'=>base64_encode(file_get_contents($folder . '/' . $d->getFilename())));
				}
			}
		}
	}
	
	/**
	 * creates our output script
	 * 
	 * @param array $info
	 * @param array $directories
	 * @param array $files
	 */
	protected function _parse($info, &$directories, &$files)
	{
		foreach ($info as $key=>$item) {
			if (!is_numeric($key)) {
				/** its probably a directory **/
				$directories[] = $key;
				$this->_parse($item, $directories, $files);
			}
			else {
				$files[] = $item;
			}
		}
	}
	
	/**
	 * make output file
	 * 
	 * Generates the script to run the directory creation
	 * and the file items
	 * 
	 * @param array $directories
	 * @param array $files
	 * 
	 * @throws exception
	 */
	protected function _makeOutputFile($directories, $files)
	{
		$templateFile = dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'template' 
						. DIRECTORY_SEPARATOR . 'installer.php';
		
		if (!file_exists($templateFile)) {
			throw new exception (__METHOD__ . 
								 ': "' . htmlentities($templateFile) . 
								 '" does not exist.');
		}
		
		/**
		 * get contents 
		 */
		$output = file_get_contents($templateFile);
		
		/**
		 * build directory string and replace it
		 */
		$directoryString = '$directories = array("' . implode('", "', $directories) . '");';
		$output = str_replace('[[directories]]', $directoryString, $output);
		

		/**
		 * build file string and replace it
		 */
		$fileString = '$files = array(';
		foreach ($files as $file) {
			$fileString .= 'array("name"=>"' . $file['name'] . '", "content"=>"' . $file['content'] . '"),';
		}
		$fileString .= ');';
		$output = str_replace('[[files]]', $fileString, $output);
		
		
		/**
		 * finally, output the file
		 */
		file_put_contents($this->_outputFileName, $output);
	}
}
?>
# I Am Present

## Presence Indicator Control for Slack

If you find that your Slack client makes you look idle more than you are, you need this app.  Sometimes, some apps
and the web interface for Slack make it look like you're idling a lot more than you are.  For example, if you don't have
the web interface focused, it might show you're idle - even though you're working hard.  You can install the native Slack
app to fix this - or - you can keep using your app of choice, and run this small app.  

I Am Present keeps you active while it's running - no more turning idle just because you're not focused on slack.

## Important Disclaimer

This application is not endorsed or created by the team at Slack.  I'm hoping that they're thrilled with the integration,
but if not - hopefully they'll send me a nice letter - offering help with how to make this compliant? :)

## Other Notes

[Development Docs](docs/development.md)


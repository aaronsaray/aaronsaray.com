# Development Docs

This project is using

[MacGap 2 Beta](https://github.com/MacGapProject/MacGap2) for this.


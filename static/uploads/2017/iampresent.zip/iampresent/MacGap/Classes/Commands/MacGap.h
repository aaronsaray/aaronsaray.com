//
//  MacGap.h
//  MG
//
//  Created by Tim Debo on 5/21/14.
//
//


#import <JavaScriptCore/JavaScriptCore.h>
#import "WindowController.h"
#import "WebViewDelegate.h"
#import "Command.h"
#import "App.h"
#import "Window.h"
#import "Menu.h"
#import "MenuItem.h"
#import "Dialog.h"
#import "Dock.h"
#import "Task.h"
#import "Notify.h"
#import "Fonts.h"
#import "StatusItem.h"
#import "Event.h"


#import "NSData+Base64.h"
#import "JSON.h"






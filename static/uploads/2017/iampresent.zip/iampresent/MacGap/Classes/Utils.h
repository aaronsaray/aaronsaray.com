//
//  Utils.h
//  MG
//
//  Created by Tim Debo on 5/28/14.
//
//

#import <Foundation/Foundation.h>

NSString *pathForResource(NSString* resourcePath);



//
//  Constants.h
//  MG
//
//  Created by Tim Debo on 5/20/14.
//
//

// Application constants

#define kStartPage @"public/index.html"
#define kStartFolder @"."
#define kWebScriptNamespace @"MacGap"

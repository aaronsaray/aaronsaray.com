/**
 * Navigation Filler script
 * 
 * Todo:
 * - Handle more than just FF 3 ;)
 * - handle style on the div
 * - handle images not loading
 * - handle any style applied to images
 * - possibly juggle around images to make the most of them fit
 * - lazy loading images for better peformance instead of loading them all when added
 */
function navigationFiller(){
    
    /**
     * The images we're going to use
     */
    this._images = new Array();
    
    /**
     * Adds images to the list
     * @param {string} imgURL
     */
    this.add = function(imgURL)
    {
        var img = new Image();
        img.src=imgURL;
        this._images[this._images.length] = img;
    }
    
    
    /**
     * Launching item - makes the div populate
     * @param {string} divID
     */
    this.create = function(divID){
        /**
         * get div and its location
         * getting based off the top - making an assumption the div is empty
         * and has no style
         */
        var fillerDiv = document.getElementById(divID);
        var topLocation = 0;
        var obj = fillerDiv;
        do {
            topLocation += obj.offsetTop;
        }
        while (obj = obj.offsetParent);
        
        
        /**
         * now get bottom of page
         */
        var pageHeight = (document.height !== undefined) ? document.height : document.body.offsetHeight;
        
        /**
         * we're making the assumption that there is no bottom footer
         * get the area to make up
         */
        var availableSpace = pageHeight - topLocation;
        var imgHeight = 0;
        
        /**
         * place all the images now
         */
        for (x in this._images) {
            imgHeight = this._images[x].height;
            
            if (imgHeight < availableSpace) {
                /**
                 * this means that we have room to put the image
                 */    
                 fillerDiv.appendChild(this._images[x]);
                 fillerDiv.appendChild(document.createElement('br'));
                
                availableSpace -= imgHeight;         
            }
            else {
                /** 
                 * no more room - stop!
                 */
                break;
            }
        }
    }
}
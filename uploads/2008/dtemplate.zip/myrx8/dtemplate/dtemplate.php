<?php
/**
 * dtemplate class
 * 
 * This file contains the dtemplate templating class code
 * 
 * @author Aaron D Saray
 */

/**
 * dtemplate 
 * 
 * The main templating class
 * 
 * Used like so:
 * <code>
 * // this is needed to build your content
 * function dtemplate_build_content(dtemplate_content $content)
 * {
 *   $content->addID('id1', 'THIS IS MY ID LINE');
 *   $content->addClass('date', time());
 * } 
 *
 * //start the template request 
 * $template = new dtemplate();
 * try {
 *  $template->setPage($_GET['page']);
 *  $template->setContent($template->prep_custom_content());
 *  echo $template->render();
 * }
 * catch (dtemplatePageNotFoundException $e) {
 *  header("HTTP/1.0 404 Not Found"); 
 *  die("<h1>404 - Page not found</h1>");
 * }
 * catch (dtemplatePageNotSetException $e) {
 *  header("HTTP/1.1 500 Internal Server Error"); 
 *  die("<h1>500 - Error on Page</h1>");
 * }
 * catch (exception $e) {
 *  header("HTTP/1.1 500 Internal Server Error"); 
 *  die("<h1>500 - Error on Page</h1>");
 * }
 * </code>
 */
class dtemplate
{
    /**
     * is a valid template file
     * @var boolean
     */
    public $valid = FALSE;

    /**
     * the name of the requested page
     * @var string
     */
    protected $_pageName = '';
    
    /**
     * The actual location of the file to be parsed
     * @var string
     */
    protected $_pageLocation = '';
    
    /**
     * dom document of our file
     * @var object
     */
    protected $_document = NULL;
    
    /**
     * The content object
     * @var dtemplate_content
     */
    protected $_content = NULL;
    
    /**
     * location where your source files are - same level of dtemplate dir
     * @var string
     */
    const SOURCE_HTML_FOLDER = 'dtemplate_sourcehtml';
    
    ############################################################################
    ############################################################################
    
    /**
     * Constructor
     * 
     * Checks to make sure that dom is loaded
     */
    public function __construct()
    {
        if (!extension_loaded('dom')) {
            trigger_error("Cannot continue - DOM extension not loaded", E_USER_ERROR);
        }
    }

    /**
     * Set the current request page
     * @param string $page
     */
    public function setPage($page)
    {
        if (!$this->_findPage($page)) {
            throw new dtemplatePageNotFoundException("Page {$page} not found");
        }
    }
    
    /**
     * Sets the current content object
     * @param dtemplate_content $obj
     */
    public function setContent(dtemplate_content $obj)
    {
        $this->_content = $obj;
    }

    /**
     * Generates output
     * 
     * Renders the HTML file into DOM, adds content to it, then returns it
     * 
     * @return string
     */
    public function render()
    {
        if (empty($this->_pageName)) {
            throw new dtemplatePageNotSetException("Page was not set before render call.");
        }

        $this->_processHTMLFile();
        $this->_processContent();
        
        /**
         * return the processed content
         */
        return $this->_document->saveHTML();
    }
    
    /**
     * used to initialize custom content
     * 
     * This function is used by this object externally to validate a custom
     * function exists, to prep the content object and then return it
     * to be processed
     *
     * @return dtemplate_content
     */
    public function prep_custom_content()
    {
        if (!function_exists('dtemplate_build_content')) {
            throw new dtemplateFrontControllerException("Missing template_build_content function in front controller");
        }
        
        $obj = new dtemplate_content($this->_pageName);
        dtemplate_build_content($obj);
        return $obj;
    }

    ############################################################################
    ############################################################################

    /**
     * Uses xpath to find each of the content and replace it with the value
     */
    protected function _processContent()
    {
        $types = array('id', 'class');
        $xpath = new DOMXPath($this->_document);
        $this->_captureXMLerrors();
        foreach ($types as $type) {
            foreach ($this->_content->$type as $key=>$value) {
                $query = "//*[@{$type}='{$key}']";
                $results = $xpath->query($query);
                if (!$results->length) {
                    $this->_err("Cannot find {$type} {$key} in document.");
                }
                else {
                    /** walk through and replace all **/
                    foreach ($results as $node) {
                        $node->nodeValue = $value;
                    }
                }
            }
        }
        $this->_restoreXMLerrors();
    }

    /**
     * Loads in the html file as a dom document and watches for any errors
     */
    protected function _processHTMLFile()
    {
        $this->_captureXMLErrors();
        $this->_document = new DomDocument();
        $this->valid = $this->_document->load($this->_pageLocation);
        $this->_collectErrors();
        $this->_restoreXMLErrors();
    }
    
    /**
     * Used to throw an exception when an error occurs, turns $valid to false
     * @param string $message
     */
    protected function _err($message)
    {
        $this->valid = FALSE;
        throw new dtemplateXMLException($message);
    }
    
    /**
     * Used to locate the page in the source html folder, then sets vars
     * @param string $page
     * @return boolean was it found?
     */
    protected function _findPage($page)
    {
        $path = realpath(dirname(__FILE__) . '/../' . self::SOURCE_HTML_FOLDER);
        if (file_exists($path . "/{$page}")) {
            $this->_pageLocation = $path . "/{$page}";
            $this->_pageName = $page;
            return true;
        }
        else {
            return false;
        }
    }
    
    /**
     * start capturing libxml errors internally
     */
    protected function _captureXMLerrors()
    {
        libxml_use_internal_errors(TRUE);
    }
    
    /**
     * Stop captureing libxml errors internally
     */
    protected function _restoreXMLerrors()
    {
        libxml_use_internal_errors(FALSE);
    }
    
    /**
     * collects any errors that we may have collected in the queue
     */
    protected function _collectErrors()
    {
        $errors = libxml_get_errors();
        if (!empty($errors)) {
            foreach ($errors as $error) {
                $this->_err(trim("Line: {$error->line}, Column: {$error->column} | {$error->message}"));
            }
            libxml_clear_errors();
        }
    }
}

/**
 * dtemplate content class
 * 
 * This class is a object to hold the content that must be replaced in the
 * dom document.  It is used by the custom user function.  It also
 * contains a reference to the page name so that the custom function can
 * use this to retrieve the content that is needed.
 */
class dtemplate_content
{
    /**
     * Holds the class names, values to replace
     * @var array
     */
    public $class = array();
    
    /**
     * holds hte id names, values to replace
     * @var array
     */
    public $id = array();
    
    ############################################################################
    ############################################################################
    
    /**
     * constructor sets the page 
     * @param string $page
     */
    public function __construct($page)
    {
        $this->page = $page;
    }
    
    /**
     * adds a class named $name with the value $value to be replaced
     * @param string $name
     * @param string $value
     */
    public function addClass($name, $value)
    {
        $this->class[$name] = $value;
    }

    /**
     * add an ID named $name with the value $value to be replaced
     *
     * @param string $name
     * @param string $value
     */
    public function addID($name, $value)
    {
        $this->id[$name] = $value;
    }
}

/**
 * Exception for not being able to find the target HTML file
 */
class dtemplatePageNotFoundException extends Exception {}

/**
 * Exception for a rendering being called without setting the page first
 */
class dtemplatePageNotSetException extends Exception {}

/**
 * Exception for an XML error (pages should have been verified first)
 */
class dtemplateXMLException extends Exception {}

/**
 * exception for custom user function is not created 
 */
class dtemplateFrontControllerException extends Exception {}
?>
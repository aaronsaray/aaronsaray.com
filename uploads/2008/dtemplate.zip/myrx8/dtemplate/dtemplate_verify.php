<?php
/**
 * this file holds the class for verifying a file for dtemplate
 * 
 * @author Aaron D Saray
 */

/**
 * dtemplate verification 
 * 
 * The class that verifies if a file is parseable by dtemplate as well as valid
 * xhtml, etc.
 * 
 * Example usage:
 * <code>
 * $file = 'test.html';
 * $ids = array('id1');
 * $classes = array('class1');
 *
 * $templateVerify = new dtemplate_verify();
 * $templateVerify->validateFile($file);
 * $templateVerify->validateItems(dtemplate_verify::ID_ATTR, $ids);
 * $templateVerify->validateItems(dtemplate_verify::CLASS_ATTR, $classes);
 * </code>
 */
class dtemplate_verify extends dtemplate
{
    /**
     * any validation errors
     * @var array
     */
    public $validationErrors = array();
    
    /**
     * constant for id search
     * @var string
     */
    const ID_ATTR = 'id';
    
    /**
     * constant for class search
     * @var string
     */
    const CLASS_ATTR = 'class';
    
    ############################################################################
    ############################################################################
    
    /**
     * validate the file
     *
     * @param string $filename
     */
    public function validateFile($filename)
    {
        if (file_exists($filename)) {
            $this->_captureXMLErrors();
            $this->_loadFile($filename);
            $this->_collectErrors();
            $this->_restoreXMLErrors();
        }
        else {
            $this->_err("The file {$filename} does not exist.");
        }
    }
    
    /**
     * Function used to validate that all of the items in the array
     * of type $type are present as attributes of some element
     * in the document
     * 
     * @param string $type 
     * @param array $values
     */
    public function validateItems($type, $values)
    {
        if (!is_null($this->_document)) {
            $this->_captureXMLErrors();
            $this->_lookForItems($type, $values);
            $this->_collectErrors();
            $this->_restoreXMLErrors();
        }
        else {
            $this->_err("The file must be validated first.");
        }
    }
    
    
    ############################################################################
    ############################################################################
    
    /**
     * process the file in the parser
     * 
     * @param string $filename
     */
    protected function _loadFile($filename)
    {
        $this->_document = new DomDocument();
        $this->valid = $this->_document->load($filename);
    }
    
     /**
     * short hand for entering error messages, flipping valid to false
     *
     * @param string $errorMessage
     */
    protected function _err($errorMessage) 
    {
        $this->valid = FALSE;
        $this->validationErrors[] = $errorMessage;
    }

    /**
     * Looks through the dom document for the list of $values of type $type
     *
     * @param string $type
     * @param array $values
     */
    protected function _lookForItems($type, $values)
    {
        $xpath = new DOMXPath($this->_document);
        foreach ($values as $value) {
            $query = "//*[@{$type}='{$value}']";
            $count = $xpath->query($query)->length;
            if (!$count) {
                $this->_err("Cannot find {$type} {$value} in document.");
            }
        }
    }
}

?>
<?php
/**
 * this is my custom logic class
 */

/**
 * this class will generate a message for the front page
 */
class customLogic
{
    public function output()
    {
        $return = "Nothing else!  This is replaced content!";
        
        if ($_SERVER['REQUEST_URI'] == '/home.html') {
            return $return;
        }
        else {
            return '';
        }
    }
}
?>
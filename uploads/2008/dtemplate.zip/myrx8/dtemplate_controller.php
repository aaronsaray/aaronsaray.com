<?php
/**
 * dtemplate controller - launches a page based on the rewritten GET request
 */

/**
 * bring in the template
 */
require 'dtemplate/dtemplate.php';

/**
 * Should we print debugging messages on error?
 */
define ('DEBUG', TRUE);

/**
 * a function to build your content
 * 
 * might be good place to do includes to bring in your own stuff, then
 * use the instance of dtemplate_content to apply it to this.
 * 
 * use $content->addClass('className', $valueString);
 * use $content->addID('idName', $valueString);
 * 
 * $content->page is available as the requested file with NO first slash
 */
function dtemplate_build_content(dtemplate_content $content)
{
    /**
     * i'm going to call my custom logic here
     */
    require 'customLogic.php';
    $n = new customLogic();
    $output = $n->output();
    
    if ($output) $content->addID('disclaimer', $output);
}




/**
 * Execute the templating request
 */
$template = new dtemplate();
try {
    $template->setPage($_GET['page']);
    $template->setContent($template->prep_custom_content());
    echo $template->render();
}
catch (dtemplatePageNotFoundException $e) {
    header("HTTP/1.0 404 Not Found"); 
    if (DEBUG) print $e->getMessage();
    die("<h1>404 - Page not found</h1>");
}
catch (dtemplatePageNotSetException $e) {
    header("HTTP/1.1 500 Internal Server Error"); 
    if (DEBUG) print $e->getMessage();
    die("<h1>500 - Error on Page</h1>");
}
catch (exception $e) {
    header("HTTP/1.1 500 Internal Server Error"); 
    if (DEBUG) print $e->getMessage();
    die("<h1>500 - Error on Page</h1>");
}
?>
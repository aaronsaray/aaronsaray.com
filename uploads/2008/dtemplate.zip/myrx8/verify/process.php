<html>
<head>
    <title>Validate File for dtemplate</title>
    <style type="text/css">
        body {
            font-family: verdana, sans-serif;
            font-size: 1em;
            background-color: #f6f6f6;
            color: #000;
        }
        h1, p {
            text-align: center
        }
        strong {
            color: #0c0;
        }
        .error {
            color: #c00;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h1>Validate File for dtemplate</h1>
    <p>Results:</p>
    <?php
    require '../dtemplate/dtemplate.php';
    require '../dtemplate/dtemplate_verify.php';
    
    if (is_uploaded_file($_FILES['xhtmlfile']['tmp_name'])) {
        foreach (array('ids', 'classes') as $type) {
            if (trim($_POST[$type]) != '') {
                $$type = explode(',', $_POST[$type]);
                $$type = array_map('trim', $$type);
            }
        }
    
        $templateVerify = new dtemplate_verify();
        $templateVerify->validateFile($_FILES['xhtmlfile']['tmp_name']);
        if (!empty($ids)) $templateVerify->validateItems(dtemplate_verify::ID_ATTR, $ids);
        if (!empty($classes)) $templateVerify->validateItems(dtemplate_verify::CLASS_ATTR, $classes);

        if ($templateVerify->valid) {
            print "<strong>{$_FILES['xhtmlfile']['name']} is valid!</strong>";
        }
        else {
            print '<span class="error">' . $_FILES['xhtmlfile']['name'] . ' is not valid:</span><ul>';
            foreach ($templateVerify->validationErrors as $error) {
                print "<li class=\"error\">{$error}</li>";
            }
            print "</ul>";
        }
        
    
    }
    else {
        print '<strong class="error">The file failed to upload.</strong>';
    }
        
    ?>
</body>
</html>
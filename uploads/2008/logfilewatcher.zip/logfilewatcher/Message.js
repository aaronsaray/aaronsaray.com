//Manages a single message window object
function Message(message){
	var currentScreen = air.Screen.screens[0];
	var animating = false;		
	
	//Moves the window onto the screen 
	var animateY = function (endY){
			var dY = 0;
			Message.prototype.setAnimating();
			var animate = function(event){
				dY = Math.floor((endY - htmlLoader.window.nativeWindow.y)/4);
				htmlLoader.window.nativeWindow.y = htmlLoader.window.nativeWindow.y + dY;
				if( htmlLoader.window.nativeWindow.y <= endY){
					htmlLoader.window.nativeWindow.y = endY;
					Message.prototype.cancelAnimating();
					htmlLoader.stage.removeEventListener(air.Event.ENTER_FRAME, animate);
				}
			}
			htmlLoader.stage.addEventListener(air.Event.ENTER_FRAME, animate);
	}
		
	//Finds a spot onscreen for a message window
	var findSpotForMessage = function (size){
		var spot = new air.Point();
		var done = false;
		for(var i = 0; i < air.Screen.screens.length; i++){
			currentScreen = air.Screen.screens[i];
			for(var x = currentScreen.visibleBounds.x + currentScreen.visibleBounds.width - size.width - 10; 
					x >= currentScreen.visibleBounds.x; 
					x -= 260){
				for(var y = currentScreen.visibleBounds.y + currentScreen.visibleBounds.height - size.height - 10;
						y >= currentScreen.visibleBounds.y;  
						y -= 10){
					var testRect = new air.Rectangle(x, y, size.width + 10, size.height + 10);
					if(!isOccupied(testRect)){
						spot.x = x
						spot.y = y;
						done = true;
						break;
					}
				}
				if(done){break;}
			}
			if(done){break;}
		}
		return spot;
	}
		
	//Checks to see if any opened message windows are in a particular spot on screen
	var isOccupied = function (testRect){
		var occupied = false;
			
		//i starts at one to skip the hidden initial window
		for (var i = 1; i < air.NativeApplication.nativeApplication.openedWindows.length; i++){
			occupied = air.NativeApplication.nativeApplication.openedWindows[i].bounds.intersects(testRect);
			if(occupied) {break;}
		}
		return occupied;
	}

	//Sets the window message variable in response to the (AIR-only) DOM initialize event.
	var onInitialize = function (){
		htmlLoader.removeEventListener(air.Event.HTML_DOM_INITIALIZE, onInitialize);
		htmlLoader.window.message = message;
	}
	
	//Displays the window and animates it's entrance once the custom "layoutComplete" event occurs
	var onComplete = function (){
			htmlLoader.removeEventListener("layoutComplete", onComplete);
			htmlLoader.window.nativeWindow.visible = true;
			var position = findSpotForMessage(htmlLoader.window.nativeWindow.bounds);
			htmlLoader.window.nativeWindow.x = position.x;			
			animateY(position.y);
	}		
	
	//Cleans up references when the window closes
	var onClose = function (){
		htmlLoader.window.nativeWindow.removeEventListener(air.Event.CLOSE, onClose);
		htmlLoader = null;
		currentScreen = null;
	}
	
	/** Main constructor logic **/
	//Create the window initialization options
	var windowOptions = new air.NativeWindowInitOptions();
	windowOptions.type = air.NativeWindowType.LIGHTWEIGHT;
	windowOptions.systemChrome = air.NativeWindowSystemChrome.NONE;
	
	//Create the window	
	var htmlLoader = air.HTMLLoader.createRootWindow(false, windowOptions, false);
	htmlLoader.window.nativeWindow.width = 250;
	htmlLoader.window.nativeWindow.y = currentScreen.bounds.height;
	htmlLoader.window.nativeWindow.alwaysInFront = true;
	htmlLoader.addEventListener(air.Event.HTML_DOM_INITIALIZE, onInitialize);
	htmlLoader.addEventListener("layoutComplete", onComplete);
	htmlLoader.window.nativeWindow.addEventListener(air.Event.CLOSE, onClose);
	
	//load the html file for the window
	htmlLoader.load(new air.URLRequest("message.html"));
}

//Indicates whether a window is currently animating
Message.prototype.isAnimating = false;

//Timeout in case the window is closed before it finishes animating
Message.prototype.animationTimeout = null;

Message.prototype.setAnimating = function (){
	Message.prototype.isAnimating = true;
	Message.prototype.animationTimeout = setTimeout(Message.prototype.cancelAnimating(), 6000);
}

Message.prototype.cancelAnimating = function (){
	Message.prototype.isAnimating = false;
	clearTimeout(Message.prototype.animationTimeout);
}
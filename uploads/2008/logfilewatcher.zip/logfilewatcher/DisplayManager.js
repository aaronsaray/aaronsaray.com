//Manages the display of the messages
function DisplayManager()
{
		var poller = new air.Timer(1500);
		var messageQueue = new Array();
		
		//Pull a message out of the queue and display it, unless an existing message window is still animating
		var dequeueMessage = function (){
			//air.trace(Message.prototype.isAnimating);
			if(!Message.prototype.isAnimating && 
			  (messageQueue.length > 0)){
					new Message(messageQueue.shift());
			}			
		}	
		
		//Push the message onto the queue	
		this.queueMessage = function (message) {
			messageQueue.push(message);
		};
		 		
		//Stop the timer when the user is away
		var pause = function (){
			air.trace("idle");
			poller.stop();
		}
		
		//Start the timer when the user returns
		var resume = function (){
			air.trace("present");
			poller.start();
		}
		
		//Set up event listeners and start timers 
 		air.NativeApplication.nativeApplication.idleThreshold = 30;		
		air.NativeApplication.nativeApplication.addEventListener(air.Event.USER_IDLE, pause);
		air.NativeApplication.nativeApplication.addEventListener(air.Event.USER_PRESENT, resume);
		poller.addEventListener(air.TimerEvent.TIMER, dequeueMessage);
		poller.start();
}		


	

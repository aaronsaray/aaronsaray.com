/**
 * Meta Tag Generator
 * @author 102degrees.com
 * @copyright http://creativecommons.org/licenses/by-sa/3.0/
 */

/**
 * Function handles the expanding / contracting of more info boxes
 * 
 * @param item {object} The link that was clicked to toggle info
 * @return {boolean} Should be false to stop the link from executing
 */
function toggleMoreInfo(item)
{
	/**
	 * create the div id
	 */
	var divid = item.id.replace(/_toggle/, "_moreinfo");
	
	/**
	 * set a toggle state
	 */
	var state = item.getAttribute('toggle');
	
	if (state && state=='true') {
		/** toggle it back off **/
		item.setAttribute('toggle', 'false');
		/** toggle div **/
		document.getElementById(divid).style.display = 'none';
		/** change content **/
		item.innerHTML = "Help and More Info";
	}
	else {
		/** toggle it on **/
		item.setAttribute('toggle', 'true');
		/** toggle div **/
		document.getElementById(divid).style.display = 'block';
		/** change content **/
		item.innerHTML = "Hide Extra Info";
	}
	
	/**
	 * return false so the link doesn't execute
	 */
	return false;
}


/**
 * javascript to generate the metatags
 */
function generateTags()
{
	var tags = '';
	
	/**
	 * keywords
	 */
	if (document.getElementById('metatag_keywords').value) {
		tags += '<meta name="keywords" content="' + 
				document.getElementById('metatag_keywords').value +
				'" />' + "\n";
	}
	
	/**
	 * description
	 */
	if (document.getElementById('metatag_description').value) {
		tags += '<meta name="description" content="' + 
				document.getElementById('metatag_description').value +
				'" />' + "\n";
	}


	/**
	 * add the content
	 */
	document.getElementById('metatag_tags').value = tags;
}
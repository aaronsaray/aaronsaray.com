Meta Tag Generator
author: 102degrees.com
copyright: http://creativecommons.org/licenses/by-sa/3.0/

This is the very first release version - a kind of proof-of-concept for this software. 
In the future, we're planning on updating the list with a larger amount of meta tags and 
better descriptions.


3 files are included:
snippet.html - This is the HTML to insert into your document.
metatag.js   - This is the javascript functionality.  You must import this into your page.
metatag.css  - This is the CSS markup.  You must import this into your page.

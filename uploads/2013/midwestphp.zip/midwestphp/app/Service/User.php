<?php
class Service_User
{
	public function findOneById($id)
	{
		$mapper = $this->_getMapper();
		$params = array('id'=>$id);
		return $mapper->findOne($params);
	}

	public function findAll($params = array())
	{
		$mapper = $this->_getMapper();
		return $mapper->findAll($params);
	}

	public function findAllCreatedBeforeToday()
	{
		$mapper = $this->_getMapper();
		$params = array('createdBefore'=>date('Y-m-d'));
		return $mapper->findAll($params);
	}

	public function createFromUserInput($params = array())
	{
		$domainValidation = $this->_getDomainValidation();

		if (!$domainValidation->validateFirstname($params)) {
			throw new Exception("First name did not validate");
		}
		if (!$domainValidation->validateLastname($params)) {
			throw new Exception("Last name did not validate");
		}

		$mapper = $this->_getMapper();
		$user = $mapper->mapFromArray($params);

		return $user;
	}

	public function applyUpdateFromUserInput(Model_User $user, $params = array())
	{
		$domainValidation = $this->_getDomainValidation();

		if (isset($params['firstname']) && !$domainValidation->validateFirstname($params)) {
		    throw new Exception("First name did not validate");
		}
		if (isset($params['lastname']) && !$domainValidation->validateLastname($params)) {
			throw new Exception("Last name did not validate");
		}

		$mapper = $this->_getMapper();
		$user = $mapper->mapFromArray($params, $user);

		return $user;
	}

	public function save(Model_User $user)
	{
		$this->_getMapper()->save($user);
		$this->_audit("User has been saved");
	}

	protected function _getMapper()
	{
		//return new Mapper_Db_User();
		return new Mapper_As400_User();
	}

	protected function _getDomainValidation()
	{
		return new Domain_User();
	}

	protected function _audit($text)
	{
		// can log text here
	}
}
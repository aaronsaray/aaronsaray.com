<?php
class Domain_User
{
	public function validateFirstname($values)
	{
		return !empty($values['firstname']) && strlen($values['firstname']) < 25;
	}

	public function validateLastname($values)
	{
		return !empty($values['lastname']) && strlen($values['lastname']) < 45;
	}
}

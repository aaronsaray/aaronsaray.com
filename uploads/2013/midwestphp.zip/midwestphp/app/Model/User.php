<?php
Class Model_User
{
	public $firstname;
	public $lastname;
	public $email;
	public $id;
	public $datecreated;

	public function getFullName()
	{
		return trim($this->firstname . ' ' . $this->lastname);
	}
}
